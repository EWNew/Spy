# 企业大数据征信系统

基于 Vue + Element UI 的企业大数据征信系统

## 项目截图

### 注册登录



![image-20200730144359297](README.assets/image-20200730144359297.png)

![image-20200730144419649](README.assets/image-20200730144419649.png)

## 主界面

![image-20200730144437520](README.assets/image-20200730144437520.png)

![image-20200730144451408](README.assets/image-20200730144451408.png)



## 市场总览

![image-20200730144502966](README.assets/image-20200730144502966.png)



## 地图查

![image-20200730144517363](README.assets/image-20200730144517363.png)





### 详细信息界面

![image-20200730144551145](README.assets/image-20200730144551145.png)

![image-20200730144600102](README.assets/image-20200730144600102.png)

![image-20200730144617502](README.assets/image-20200730144617502.png)

![image-20200730144635456](README.assets/image-20200730144635456.png)



## 功能

-   [x] 登陆/注册
-   [x] 地图查
-   [x] 市场总览
-   [x] 公司名/信用代码查询
-   [x] 查看新闻/征信咨询
-   [x] 查看公司详细信息
-   [x] 一键复制详细信息
-   [x] 使用者反馈信息

## 安装步骤

```
 // 进入模板目录
npm install         // 安装项目依赖，等待安装完成之后，安装失败可用 cnpm 或 yarn

// 开启服务器，浏览器访问 http://localhost:8080
npm run serve

// 执行构建命令，生成的dist文件夹放在服务器下即可访问
npm run build
```

# 欢迎提供反馈意见

