import Vue from 'vue';
import Router from 'vue-router';
import { component } from 'vuedraggable';

Vue.use(Router);

export default new Router({
    routes: [
        {
            path:'/',
            redirect: '/search',
        },
       
        {
            path: '/',
            component: () => import(/* webpackChunkName: "home" */ '../components/common/Home.vue'),
            meta: { title: '页面头' },
            children: [
                {
                    path: "/search",
                    component: () => import(/* webpackChunkName: "search" */ '../components/common/Search.vue'),
                    meta: { title: '搜索界面' }
                },
                {
                    path: "/list",
                    component: () => import(/* webpackChunkName: "search" */ '../components/page/List.vue'),
                    meta: {title: '公司列表' }
                },
                {
                    path: "/detail_info",
                    component: () => import(/* webpackChunkName: "search" */ '../components/page/Detail_info.vue'),
                    meta: {title: '详细信息'}
                },
            ]
        },

        {
            path: '/login',
            component: () => import(/* webpackChunkName: "login" */ '../components/page/Login.vue'),
            meta: { title: '登录界面' }
        },
        {
            path: '/register',
            component: () => import(/* webpackChunkName: "register" */ '../components/page/Register.vue'), 
            meta: { title: '注册界面' },
        },
        {
            path: '/overview',
            component: () => import(/* webpackChunkName: "overview" */ '../components/page/Overview.vue'), 
            meta: { title: '市场总览' },
        },        
        {
            path: '*',
            component: () => import(/* webpackChunkName: "404" */ '../components/page/404.vue'), 
            meta: { title: '404界面' },
        }
    ]
});