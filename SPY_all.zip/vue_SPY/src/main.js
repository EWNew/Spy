import Vue from 'vue';
import App from './App.vue';
import router from './router';
import ElementUI from 'element-ui';
import { messages } from './components/common/i18n';
import 'element-ui/lib/theme-chalk/index.css'; // 默认主题
// import './assets/css/theme-green/index.css'; // 浅绿色主题
import './assets/css/icon.css';
import 'babel-polyfill';
import VueParticles from 'vue-particles'
import SERVICE_PATH from "./config"
import VueClipboard from 'vue-clipboard2'
import echarts from 'echarts'

Vue.prototype.$echarts = echarts
Vue.use(VueClipboard)
Vue.use(VueParticles)
Vue.config.productionTip = false;
Vue.use(ElementUI, {
    size: 'small'
});
Vue.prototype.SERVICE_PATH = SERVICE_PATH;

//使用钩子函数对路由进行权限跳转
router.beforeEach((to, from, next) => {
    document.title = `${to.meta.title} | SPY-征信系统`;
    const role = localStorage.getItem('ms_username');
    
    if (!role && to.path !== '/login' && from.path !== '/login') {
        next('/login');
    } 
    else {
       next();
    }
});

new Vue({
    router,
    render: h => h(App)
}).$mount('#app');
