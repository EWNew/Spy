<template>
    <div class="wrapper">
        <v-head></v-head>
        <div class="content">
            <div class="centerPage">
                <router-view></router-view>
                 
            </div>
            <el-backtop target=".content"></el-backtop>
        </div>
    </div>
</template>

<script>
import vHead from './Header.vue';
export default {
    data() {
        return {
            
        };
    },
    components: {
        vHead,
    },
};
</script>
