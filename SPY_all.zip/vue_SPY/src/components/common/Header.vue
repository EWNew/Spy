<template>
    <div class="header" >
        <!-- 折叠按钮 -->
        <div class="collapse-btn">
            <i class="el-icon-view"></i>
        </div>
        <div class="logo">企业大数据征信系统</div>
        <el-button round
            size="medium"
            type="primary" 
            icon="el-icon-search" 
            @click="MapSearch()"
            class="ms_btn"
        >
            地图查
        </el-button>
        <el-button round
            size="medium"
            type="primary" 
            icon="el-icon-s-data" 
            @click="marketOverview()"
            class="ms_btn"
        >
            市场总览
        </el-button>
        <el-button round
            size="medium"
            type="success" 
            icon="el-icon-money" 
            @click="V5()"
            class="ms_btn"
        >
            支持我们
        </el-button>
        <div class="header-right">
            <div class="header-user-con">

                <!-- 用户头像 -->
                <div class="welcome">
                    欢迎！
                </div>
                <!-- 用户名下拉菜单 -->
                <el-dropdown class="user-name" trigger="click" @command="handleCommand">
                    <span class="el-dropdown-link">
                        {{username}}
                        <i class="el-icon-caret-bottom"></i>
                    </span>
                    <el-dropdown-menu slot="dropdown">
                        <el-dropdown-item command="loginout">退出登录</el-dropdown-item>
                    </el-dropdown-menu>
                </el-dropdown>
                <el-button class = "returnMain"  @click="returnMains()"> 返回首页 </el-button>
            </div>
            
        </div>
    </div>
</template>
<script>
import bus from '../common/bus';
export default {
    data() {
        return {
            collapse: false,
            fullscreen: false,
            name: '',
            message: 2
        };
    },
    computed: {
        username() {
            let username = localStorage.getItem('ms_username');
            return username ? username : this.name;
        }
    },
    methods: {
        // 用户名下拉菜单选择事件
        handleCommand(command) {
            if (command == 'loginout') {
                localStorage.removeItem('ms_username');
                this.$router.push('/login');
            }
        },
        // 侧边栏折叠
        collapseChage() {
            this.collapse = !this.collapse;
            bus.$emit('collapse', this.collapse);
        },
        returnMains() {
            this.$router.push('/');
        },
        MapSearch()
        {
            //this.$router.push('/charts');
            window.open("http://www.ewnb.top/world.html");
        },
        marketOverview()
        {
            //this.$router.push('/overview');
            let routerURL = this.$router.resolve({
                path:"/overview",
        
            });
            window.open(routerURL.href, '_blank');
        },
        V5() {
            const h = this.$createElement;
            this.$notify({
            title: 'V我5块',
            message: h('img',{style:'width:280px;height:400px;background-size:cover;background-size:cover;background-image:url('+require('../../assets/img/V5.jpg')+')'}),
            duration: 0
            });
        }
    },
    mounted() {
        if (document.body.clientWidth < 1500) {
            this.collapseChage();
        }
    }
};
</script>
<style scoped>
.header {
    position: relative;
    box-sizing: border-box;
    width: 100%;
    height: 70px;
    font-size: 22px;
    color: #fff;
}
.welcome
{
    font-size: 15px;
}
.collapse-btn {
    float: left;
    padding: 0 21px;
    cursor: pointer;
    line-height: 70px;
}
.header .logo{
    float: left;
    width: 250px;
    line-height: 70px;
}
.ms_btn {
    margin-top: 16px;
}
.header-right {
    float: right;
    padding-right: 50px;
}
.returnMain {
    float : right;
    margin-left: 10px;
}
.header-user-con {
    display: flex;
    height: 70px;
    align-items: center;
}
.btn-bell,

.btn-bell .el-icon-bell {
    color: #fff;
}
.user-name {
    margin-left: 10px;
}
.user-avator {
    margin-left: 20px;
}

.el-dropdown-link {
    color: #fff;
    cursor: pointer;
}
.el-dropdown-menu__item {
    text-align: center;
}
</style>
