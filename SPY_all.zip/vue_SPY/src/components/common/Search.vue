<template>

<div class = "wrap" style="height:1500px;">
        <el-row class = "up_row">
            <el-col :span = "10" offset = 7 class = "searchmodule">
                <el-form class="searchItem" @submit.native.prevent>
                    <el-tabs v-model="chosenTab" @tab-click="handleClick" class="SearchTabs">
                        <el-tab-pane label="全部" name="all"></el-tab-pane>
                        <el-tab-pane label="公司名称" name="name"></el-tab-pane>
                        <el-tab-pane label="信用代码" name="code"></el-tab-pane>
                    </el-tabs>
                    <el-form-item class = "serach">
                        <el-input placeholder="请输入内容" 
                            v-model="search_text"
                            @keyup.enter.native="search()" 
                            clearable
                        >
                            <el-button slot="append" 
                                icon="el-icon-search"
                                @click="search()"
                            >
                            搜索
                            </el-button>
                        </el-input>
                    </el-form-item>
                </el-form>
            </el-col>
        </el-row>
        <el-divider></el-divider>
        <div class="center">
            <el-row class="centerContent">
                <el-col :span="6" offset = 1>
                    <el-card class="box-card" shadow="always">
                        <div slot="header" class="clearfix">
                            <h3>征信咨询</h3>
                            
                        </div>
                        <div v-for="li_el in news" 
                            :key="li_el" 
                            class="text item" 
                        >
                            <p class="title" 
                                @click="toUrl(li_el.url)"
                                style="overflow:hidden;"
                            >{{li_el.title}}</p>
                        </div>
                    </el-card>
                </el-col>
                <el-col :span="8" offset=1>
                    <div class="block">
                        <el-carousel height="435px" indicator-position="outside" >
                        <div v-for="image in imageURL" :key="image">
                            <el-carousel-item class="carouselItem">
                                <el-image 
                                    class="carouselImg"
                                    style="width: 628px; height: 400px;"
                                    :src="image.imgurl"
                                    :fit="fit"
                                    @click="jumptoimagecontent(image.weburl)"
                                >
                                </el-image>
                                <div class="DIT">
                                <span class="imgTitle" @click="jumptoimagecontent(image.weburl)">
                                    {{image.title}}
                                </span>
                                </div>                        
                            </el-carousel-item>
                        </div>
                        </el-carousel>
                    </div>
                </el-col>
                <el-col :span="6" offset=1>
                    <el-card class="box-card" shadow="always">
                        <div slot="header" class="clearfix">
                            <h3>失信名单</h3>
                            
                        </div>
                        <div v-for="li_el in loserList" 
                            :key="li_el" 
                            class="text item" 
                        >
                            <p class="title"  @click="toUrl(li_el.url)">{{li_el.title}}</p>
                        </div>
                    </el-card>
                </el-col>
            </el-row>
        </div>
        <el-divider></el-divider>
        <div class="center_b">
            <el-row v-for="news in recentNews" :key="news">

                    <el-col span="10" offset="1" >
                        <el-card class="recentNews_card" shadow="hover">
                            <el-col span="10">
                                <el-image class="recNews_img" 
                                    :src="news.AimageUrl"
                                    :fit="fit"
                                    style="display:flex;"
                                    @click="toRecentNews(news.Aurl)"
                                >
                                </el-image>
                            </el-col>
                            <el-col span="12" offset="1">
                                <h2 class="h_hover" @click="toRecentNews(news.Aurl)">{{news.Atitle}}</h2>
                                <br><br><br>
                                <span class="rel_font" @click="toComp(news.AurlB)">{{news.Arelevant}}</span>
                            </el-col>
                        </el-card>
                    </el-col>
                    <el-col span="10" offset="2">
                        <el-card class="recentNews_card" shadow="hover">
                            <el-col span="10">
                                <el-image class="recNews_img" 
                                    :src="news.BimageUrl"
                                    :fit="fit"
                                    style="display:flex;"
                                    @click="toRecentNews(news.Burl)"
                                >
                                </el-image>
                            </el-col>
                            <el-col span="12" offset="1" >
                                <h2 class="h_hover" @click="toRecentNews(news.Burl)">{{news.Btitle}}</h2>
                                <br><br><br>
                                <span class="rel_font" @click="toComp(news.BurlB)">{{news.Brelevant}}</span>
                                
                            </el-col>
                        </el-card>
                    </el-col>
            </el-row>
        </div>
        <el-divider></el-divider>
        <div class="bottom"> 
            <span class="bottomtext">
                Writen By 15组Debugger
            </span>
        </div>
        <div style="height:100px;"> 
        </div>
</div>

</template>
<script>
import axios from "axios";
export default {
    created(){
        axios.get(this.SERVICE_PATH + "newsURL.json")
        .then(
            response=>{
            this.news = response.data.news;
        })
        .catch(err=>{
            console.log(err)
        });
        axios.get(this.SERVICE_PATH + "imageURL.json")
        .then(response=>{
            this.imageURL = response.data.imageURL;
        })
        .catch(err=>{
            console.log(err)
        });
        axios.get(this.SERVICE_PATH + "loserList.json")
        .then(response=>{
            this.loserList = response.data.loserList;
        })
        .catch(err=>{
            console.log(err)
        });
        axios.get(this.SERVICE_PATH + "recentNews.json")
        .then(response=>{
            this.recentNews = response.data.recentNews;
        })
        .catch(err=>{
            console.log(err)
        });
    },
    data(){
        return {
            search_text : '',
            chosenTab: 'all',
            news: [],
            imageURL: [],
            loserList: [],
            recentNews: [],
        }
    },
    methods: {
        search(){
            if(this.search_text)
            {
                //传值并跳转到下个页面 下个页面必须要接受不然会卡死
                this.$router.push({path:'/list',query:{inputText: this.search_text,chosen: this.chosenTab}});
                //直接跳转网页
                //this.$router.push('/list');
            }
            else
            {
                this.$message.error('请输入搜索信息');
            }
        },
        handleClick() {
            console.log(this.activeName);
        },
        toUrl(Url)
        {
            window.open(Url);
        },
        jumptoimagecontent(Url)
        {
            window.open(Url);
        },
        toComp(Url)
        {
            window.open(Url);
        },
        toRecentNews(Url)
        {
            window.open(Url);
        }
    },
}
</script>
<style>
.up_row
{

    background-image: url("../../assets/img/spy.png");
    background-size: cover;
}
.center {
    background-image: url("../../assets/img/bottombackground.png");
    background-size: cover;
    padding-bottom: 50px;
    padding-top: 50px;
    border-radius: 10px;
}
.center_b {
    background-image: url("../../assets/img/bottombackground.png");
    background-size: cover;
    border-radius: 10px;
}
.searchItem {
    padding: 12px 12px 0px 12px;
    margin-top: 300px;
    margin-bottom: 50px;
}
.searchInput {
    position: absolute;
    left: 50%;
    top: 40%;
    width: 700px;
    margin: -200px 0 0 -360px;
    border-radius: 5px;
    background: rgba(19, 12, 12, 0.3);
    overflow: hidden;
}
.text {
    font-size: 18px;
    border:1px solid black;
    border-radius: 5px;
  }

  .item {
    margin-bottom: 18px;
  }
.el-carousel__item h3 {
    color: #475669;
    font-size: 14px;
    opacity: 0.75;
    line-height: 400px;
    margin: 0;
}

  .el-carousel__item:nth-child(2n) {
     background-color: #99a9bf;
  }
  
  .el-carousel__item:nth-child(2n+1) {
     background-color: #d3dce6;
  }
.el-tabs__item{
    color: coral;
}
.title {
    margin-left: 10px;
}
.bottom {
    background-image: url("../../assets/img/bottombackground.png");
    background-size: cover;
    padding-top: 20px;
    padding-bottom: 40px;
    padding-right: 10px;
    border-radius: 10px;
}
.bottomtext {
    float: right;
    padding-right: 60px;
}
.imgTitle {
    padding-left: 10px;
    font-size: 20px;
    overflow: hidden;
}
.DIT {
    background-color:rgba(0, 0, 0, 0.76);
    color:cornsilk
}
.carouselItem {
    border-radius: 10px;
}

.el-carousel__item {
    border-radius: 10px;
}
.recNews_img {
    height: 200px;
}
.rel_font {
    font-size: 20px;
}
.recentNews_card {
    padding-bottom: 20px;
    margin-bottom: 10px;
    margin-top: 10px;
}
.h_hover:hover {
    color:steelblue;
    cursor: pointer;
}
.rel_font:hover {
    color:steelblue;
    cursor: pointer;
}
.title:hover {
    color:royalblue;
    cursor: pointer;
}
.carouselImg:hover {
    cursor: pointer;
}
.recNews_img:hover {
    cursor: pointer;
}
.imgTitle:hover {
    cursor: pointer;
}
</style>