<template>
    <div class="ListUI">
        <el-row class="list_1_row1">
            <el-col :span="4" offset="5" class="logo_col">
                <el-card :body-style="{ padding: '5px'}" shadow="always" class="logo">
                    <img src="../../assets/img/SPY_s.png" class="logoimage">
                </el-card>
            </el-col>
            <el-col :span="10" >
                <el-form class="ListsearchItem" @submit.native.prevent>
                    <el-tabs v-model="chosenTab" @tab-click="handleClick" type="card" class="ListTabs">
                        <el-tab-pane label="全部" name="all"></el-tab-pane>
                        <el-tab-pane label="公司名称" name="name"></el-tab-pane>
                        <el-tab-pane label="信用代码" name="code"></el-tab-pane>
                    </el-tabs>
                    <el-form-item class = "Listserach">
                        <el-input placeholder="请输入内容" 
                            v-model="search_text" 
                            @keyup.enter.native="search_test()"
                            clearable
                        >
                            <el-button slot="append" 
                                icon="el-icon-search"
                                @click="search_test()"
                            >
                            搜索
                            </el-button>
                        </el-input>
                    </el-form-item>
                </el-form>
            </el-col>
        </el-row>
        <el-divider></el-divider>
        <div class="infoList">
            <el-row>
                <el-col :span="18" offset="3">
                    <el-card>
                        <h3>以下是您搜索得关于“{{input_text}}”的结果.</h3>
                    </el-card>
                    <el-card v-if= "flag === 'false'"
                        style="margin-top:10px;"
                    >
                        <h3>未搜索到相关内容。</h3>
                    </el-card>
                </el-col>
            </el-row>
            <el-row v-for= "info in companyInfo_byName" :key=info class="list_2_row">
                <el-col :span="18" offset="3" class="info_col">
                    <el-card class="info" shadow="hover">
                        <div>
                            <div class="first_row">
                                <span @click="toComUrl(info.creditCode,info.companyName)" class="first compName">公司名: {{info.companyName}}</span>
                            </div>
                            <div class="after_row">
                                <span class="first">法定代表人: {{info.legalRepresentative}}</span>
                                <span class="after">成立时间: {{info.estabDate}}</span>
                            </div>
                            <div class="after_row">
                                <span v-if="info.email" class="first">邮箱: {{info.email}}</span>
                                <span v-if="info.phone" class="after">电话: {{info.phone}}</span>
                            </div>
                            <div class="after_row">
                                <span class="first">地址: {{info.regisAdress}}</span>
                            </div>
                        </div>
                        <div class="btn_div">
                            <el-button type="primary" plain 
                                class="detail_Btn" 
                                @click="toComUrl(info.creditCode,info.companyName)"
                            >
                                查看详细信息
                            </el-button>
                        </div>
                    </el-card>
                </el-col>
            </el-row>
            <el-row v-for= "info in companyInfo_byCode" :key=info class="list_2_row">
                <el-col :span="18" offset="3" class="info_col">
                    <el-card class="info" shadow="hover">
                        <div>
                            <div class="first_row">
                                <span @click="toComUrl(info.creditCode,info.companyName)" class="first compName">公司名: {{info.companyName}}</span>
                            </div>
                            <div class="after_row">
                                <span class="first">法定代表人: {{info.legalRepresentative}}</span>
                                <span class="after">成立时间: {{info.estabDate}}</span>
                            </div>
                            <div class="after_row">
                                <span v-if="info.email" class="first">邮箱: {{info.email}}</span>
                                <span v-if="info.phone" class="after">电话: {{info.phone}}</span>
                            </div>
                            <div class="after_row">
                                <span class="first">地址: {{info.regisAdress}}</span>
                            </div>
                        </div>
                        <div class="btn_div">
                            <el-button type="primary" plain 
                                class="detail_Btn" 
                                @click="toComUrl(info.creditCode,info.companyName)"
                            >
                                查看详细信息
                            </el-button>
                        </div>
                    </el-card>
                </el-col>
            </el-row>
        </div>
        
    </div>

</template>

<script>
import axios from "axios";
import { Loading } from 'element-ui';
export default {
    created() {
        let loadingInstance = Loading.service({ fullscreen: true });
        //console.log(this.flag);
        this.flag = 'true';
        //var  qs = require('qs');
        this.input_text = this.$route.query.inputText;
        this.lastChosen = this.$route.query.chosen
        /*
        axios.get(this.SERVICE_PATH + "companyInfo.json")
        .then(response=>{
            this.companyInfo = response.data.companyInfo;
        })
        .catch(err=>{
            console.log(err)
        });
        */
        /*
        axios.post("http://121.89.181.241:8081", qs.stringify({
                        "phone":this.param.phonenumber,
                        "name":this.param.username,
                        "pwd":this.param.password,
                    },
                    {indices:false}))
                    */
        var qs_list = require('qs');
        if(this.lastChosen === "name")
            {
                //console.log(1);
                this.flag = 'true';
                axios.post("http://121.89.181.241:8081/Search/nameSearch",qs_list.stringify({
                            "name" : this.input_text,
                        },{indices:false}))
                        .then(response=>{
                            console.log(response.data);
                            if(response.data.errcode==="0"){
                                this.companyInfo_byName = response.data.result;
                            }
                            else if(response.data.errcode==="20001")
                            {
                                console.log(response.data);
                                this.$message.error('connect but error');
                            }
                            if(this.companyInfo_byName.length === 0)
                                this.flag = 'false';
                            this.$nextTick(() => { // 以服务的方式调用的 Loading 需要异步关闭
                                loadingInstance.close();
                            });
                        })
            }
            else if(this.lastChosen === "code")
            {
                //console.log(2);
                this.flag = 'true';
                axios.post("http://121.89.181.241:8081/Search/codeSearch",qs_list.stringify({
                            "code" : this.input_text,
                        },{indices:false}))
                        .then(response=>{
                            //console.log(response.data);
                            if(response.data.errcode==="0"){
                                
                                this.companyInfo_byCode = response.data.result;
                                this.$nextTick(() => { // 以服务的方式调用的 Loading 需要异步关闭
                                    loadingInstance.close();
                                });
                            }
                            else if(response.data.errcode==="20001")
                            {
                                console.log(response.data);
                                this.$message.error('connect but error');
                                this.$nextTick(() => { // 以服务的方式调用的 Loading 需要异步关闭
                                    loadingInstance.close();
                                });
                            }
                            if(this.companyInfo_byCode.length === 0)
                                this.flag = 'false';
                            this.$nextTick(() => { // 以服务的方式调用的 Loading 需要异步关闭
                                loadingInstance.close();
                            });
                        })
                
            }
            else if(this.lastChosen === "all")
            {
                this.count = 0;
                this.flag = 'true';
                axios.post("http://121.89.181.241:8081/Search/nameSearch",qs_list.stringify({
                            "name" : this.input_text,
                        },{indices:false}))
                        .then(response=>{
                            if(response.data.errcode==="0"){                             
                                this.companyInfo_byName = response.data.result;
                            }
                            else if(response.data.errcode==="20001")
                            {
                                //console.log(response.data);
                                this.$message.error('connect but error');
                            }
                            if(this.count == 0)
                            {
                                this.count = this.count + 1;
                            }
                            else if(this.count == 1)
                            {
                                if(this.companyInfo_byCode.length + this.companyInfo_byName.length === 0)
                                    this.flag = 'false';
                                this.$nextTick(() => { // 以服务的方式调用的 Loading 需要异步关闭
                                    loadingInstance.close();
                                });
                            }
                        })
                axios.post("http://121.89.181.241:8081/Search/codeSearch",qs_list.stringify({
                            "code" : this.input_text,
                        },{indices:false}))
                        .then(response=>{
                            if(response.data.errcode==="0"){
                                
                                this.companyInfo_byCode = response.data.result;
                            }
                            else if(response.data.errcode==="20001")
                            {
                                //console.log(response.data);
                                this.$message.success('connect but error');
                            }
                            if(this.count == 0)
                            {
                                this.count = this.count + 1;
                            }
                            else if(this.count == 1)
                            {
                                if(this.companyInfo_byCode.length + this.companyInfo_byName.length === 0)
                                    this.flag = 'false';
                                this.$nextTick(() => { // 以服务的方式调用的 Loading 需要异步关闭
                                    loadingInstance.close();
                                });
                            }
                        })
            }
            
            
            //console.log(this.flag);
    },
    data() {
        return {
            input_text :'',
            count: 0,
            lastChosen :'',
            search_text : '',
            chosenTab: "all",
            companyInfo: [],
            companyInfo_byCode: [],
            companyInfo_byName: [],
            flag: 'true',
        };
    },
    methods: {
        search(){
            if(this.search_text)
            {
                var sendInfo = {
                    "input": this.search_text,
                    "index": 111,
                }
                this.input_text = this.search_text;
                axios.get(this.SERVICE_PATH + "companyInfo.json", sendInfo)
                .then(response=>{
                    this.companyInfo = response.data.companyInfo;
                    //目前刷新页面暂时用不到，等后面与数据库链接后，再看看
                    //location.reload();
                })
                .catch(err=>{
                    console.log(err)
                });
                //location.reload();
            }
            else
            {
                this.$message.error('请输入搜索信息');
                
            }
        },
        search_test() {
            let loadingInstance = Loading.service({ fullscreen: true });
            this.input_text = this.search_text;
            var qs_list = require('qs');
            if(this.chosenTab === "name")
            {
                //console.log(1);
                this.flag = 'true';
                axios.post("http://121.89.181.241:8081/Search/nameSearch",qs_list.stringify({
                            "name" : this.search_text,
                        },{indices:false}))
                        .then(response=>{
                            console.log(response.data);
                            if(response.data.errcode==="0"){
                                
                                this.companyInfo_byName = response.data.result;
                                this.companyInfo_byCode = [];
                            }
                            if(response.data.errcode==="20001")
                            {
                                console.log(response.data);
                                this.$message.success('connect but error');
                            }
                            if(this.companyInfo_byName.length === 0)
                                this.flag = 'false';
                            this.$nextTick(() => { // 以服务的方式调用的 Loading 需要异步关闭
                                loadingInstance.close();
                            });
                        })
            }
            else if(this.chosenTab === "code")
            {
                //console.log(2);
                this.flag = 'true';
                axios.post("http://121.89.181.241:8081/Search/codeSearch",qs_list.stringify({
                            "code" : this.search_text,
                        },{indices:false}))
                        .then(response=>{
                            console.log(response.data);
                            if(response.data.errcode==="0"){
                                
                                this.companyInfo_byCode = response.data.result;
                                this.companyInfo_byName = [];
                            }
                            if(response.data.errcode==="20001")
                            {
                                //console.log(response.data);
                                this.$message.success('connect but error');
                            }
                            if(this.companyInfo_byCode.length === 0)
                                this.flag = 'false';
                            this.$nextTick(() => { // 以服务的方式调用的 Loading 需要异步关闭
                                loadingInstance.close();
                            });
                        })
            }
            else if(this.chosenTab === "all")
            {
                this.flag = 'true';
                this.count = 0;
                console.log("count = " + this.count);
                axios.post("http://121.89.181.241:8081/Search/nameSearch",qs_list.stringify({
                            "name" : this.search_text,
                        },{indices:false}))
                        .then(response=>{
                            if(response.data.errcode==="0"){
                                
                                this.companyInfo_byName = response.data.result;
                            }
                            if(response.data.errcode==="20001")
                            {
                                console.log(response.data);
                                this.$message.success('connect but error');
                            }
                            console.log("count = " + this.count);
                            if(this.count == 0)
                            {
                                this.count = this.count + 1;
                            }
                            else if(this.count == 1)
                            {
                                if(this.companyInfo_byCode.length + this.companyInfo_byName.length === 0)
                                    this.flag = 'false';
                                this.$nextTick(() => { // 以服务的方式调用的 Loading 需要异步关闭
                                    loadingInstance.close();
                                });
                            }
                        })
                axios.post("http://121.89.181.241:8081/Search/codeSearch",qs_list.stringify({
                            "code" : this.search_text,
                        },{indices:false}))
                        .then(response=>{
                            if(response.data.errcode==="0"){
                                
                                this.companyInfo_byCode = response.data.result;
                            }
                            if(response.data.errcode==="20001")
                            {
                                //console.log(response.data);
                                this.$message.success('connect but error');
                            }
                            console.log("count = " + this.count);
                            if(this.count == 0)
                            {
                                this.count = this.count + 1;
                            }
                            else if(this.count == 1)
                            {
                                if(this.companyInfo_byCode.length + this.companyInfo_byName.length === 0)
                                    this.flag = 'false';
                                this.$nextTick(() => { // 以服务的方式调用的 Loading 需要异步关闭
                                    loadingInstance.close();
                                });
                            }
                        })
            }
        },
        handleClick() {

        },
        toComUrl(creCode, Cname)
        {
            //要改成传递公司名和代号的传递方式
            //this.$router.push('/detail_info');
            console.log(creCode);
            console.log(Cname);
            this.$router.push({path:'/detail_info',
            query:{
                creditCode: creCode,
                companyName: Cname,
            }});
            
            //window.open(URL);
        }
    },
}
</script>



<style>
.ListUI {
    padding-top: 20px;

}
.logo {
    width: 210px;
}
.list_1_row1 {
    background-color:rgb(43, 43, 43);
    padding-top: 10px; 
    border-radius: 10px;
}
.logoimage {
    display: cover;
    width: 100%;
    width: 200px;
    height: 124px;
  }
.ListsearchItem {
    padding: 15px 12px 0px 12px;
    margin-top: 0px;
    margin-bottom: 50px;
    top:20%;
}

.el-tabs__item{
    color: coral;
}

.list_2_row {
    margin-top: 20px;
}
.infoList {
    padding-top: 10px;
    padding-bottom: 100px;
    background-image: url("../../assets/img/bottombackground.png");
    background-size: cover;
}
.info {
    padding: 0px;
}
.after_row{
    margin-top: 4px;
}
.first {
    margin-left: 10px;   
}
.after{
    margin-left: 10px;
}
.compName
{
    color:royalblue;
    cursor: pointer;
}
.btn_div {
    float:right;
    padding-bottom: 12px;
    padding-right: 5px;
}
.detail_Btn {
    size: 100px;
}
.compName:hover {
    color:royalblue;
    text-decoration: underline;
    cursor: pointer;
}
</style>