<template>
    <div class="detail_info_UI">
        <el-row class="list_1_row">
            <el-col :span="4" offset="5" class="logo_col">
                <el-card :body-style="{  padding: '5px'}" shadow="always" class="logo">
                    <img src="../../assets/img/SPY_s.png" class="logoimage" />
                </el-card>
            </el-col>
            <el-col :span="10">
                <el-form class="ListsearchItem" @submit.native.prevent>
                    <el-tabs
                        v-model="chosenTab"
                        @tab-click="handleClick"
                        type="card"
                        class="ListTabs"
                    >
                        <el-tab-pane label="全部" name="all"></el-tab-pane>
                        <el-tab-pane label="公司名称" name="name"></el-tab-pane>
                        <el-tab-pane label="信用代码" name="code"></el-tab-pane>
                    </el-tabs>
                    <el-form-item class="Listserach" @submit.native.prevent>
                        <el-input
                            placeholder="请输入内容"
                            v-model="search_text"
                            clearable
                            @keyup.enter.native="search()"
                        >
                            <el-button slot="append" icon="el-icon-search" @click="search()">搜索</el-button>
                        </el-input>
                    </el-form-item>
                </el-form>
            </el-col>
        </el-row>

        <el-row :gutter="15" class="firstRow">
            <el-col :span="8">
                <el-row class="firstRowOne">
                    <el-col :span="20" offset="0" class="info_col">
                        <el-card class="info" shadow="hover">
                            <div class="first_row">
                                <span>公司名: {{companyBasicInfo.companyName}}</span>
                            </div>
                            <div class="after_row">
                                <span class="row1">行业: {{companyBasicInfo.industry}}</span>
                            </div>
                            <div class="row3">公司类型: {{companyBasicInfo.companyType}}</div>
                        </el-card>
                    </el-col>
                </el-row>
            </el-col>

            <el-col :span="10">
                <el-row class="firstRowTwo">
                    <el-col :span="20" offset="0" class="info_col">
                        <el-card class="info" shadow="hover">
                            <div class="first_row">
                                <span>法人: {{companyBasicInfo.legalRepresentative}}</span>
                            </div>

                            <div class="after_row">
                                <span class="row1">成立时间: {{companyBasicInfo.estabDate}}</span>
                                <span class="row2">注册资本(万元): {{companyBasicInfo.regCapital}}</span>
                            </div>

                            <div class="row3">地址: {{companyBasicInfo.regisAdress}}</div>
                        </el-card>
                    </el-col>
                </el-row>
            </el-col>

            <el-col :span="6">
                <el-row class="firstRowThree">
                    <el-col :span="24" offset="0" class="info_col">
                        <el-card class="info" shadow="hover">
                            <div class="first_row">
                                <span>营业日期: {{companyBasicInfo.businessTerm}}</span>
                            </div>
                            <div class="after_row">
                                <span class="row1">统一社会信用代码: {{companyBasicInfo.creditCode}}</span>
                            </div>

                            <div 
                                class="row4"
                                @click="openwebsite()"
                            >官方网址: <span class=website>{{companyBasicInfo.website}}</span></div>
                        </el-card>
                    </el-col>
                </el-row>
            </el-col>
        </el-row>

        <el-card shadow="hover">
            <div slot="header" class="infotable3">
                <span style="font-size:18px ; font-weight: 520">财务数据</span>
                <span class="rowhead3">
                    <!-- <el-button
                        slot="prepend"
                        icon="el-icon-document-copy"
                        @click="financecopy()"
                    >一键复制</el-button>-->
                    <el-button
                        slot="prepend"
                        @click="drawer = true"
                        type="primary"
                        style="margin-left: 15px;"
                    >点击查看同地区数据分析</el-button>
                    <el-button
                        slot="prepend"
                        @click="drawer2 = true"
                        type="primary"
                        style="margin-left: 15px;"
                    >点击查看同行业数据分析</el-button>
                </span>
            </div>
            <el-row :gutter="20" class="infotablerowthree" style="overflow-x:auto;overflow-y:auto;">
                <el-col :span="4">
                    <div class="first">收入: {{finance.income}}</div>
                </el-col>
                <el-col :span="4">
                    <div class="second">公司总资产: {{finance.totalAssets}}</div>
                </el-col>
                <el-col :span="4">
                    <div class="third">公司净资产: {{finance.netAssets}}</div>
                </el-col>
                <el-col :span="4">
                    <div class="forth">公司总负债: {{finance.totalLiability}}</div>
                </el-col>
                <el-col :span="4">
                    <div class="fifth">公司营业利润: {{finance.profit}}</div>
                </el-col>
                <el-col :span="4">
                    <div class="sixth">公司净利润: {{finance.netProfit}}</div>
                </el-col>
            </el-row>
        </el-card>

        <el-drawer :visible.sync="drawer" :with-header="false">
            <el-card style="margin-top:10px">
                <div>当前省份/地区为: {{provinceInfo.province}} , 该公司名为: {{provinceInfo.companyName}}</div>
            </el-card>

            <el-card style="margin-top:10px">
                <span>
                    <el-progress
                        type="dashboard"
                        :percentage="assetsRankdata"
                        color="brown"
                        stroke-width="12"
                        width="137"
                        stroke-linecap="butt"
                    ></el-progress>
                </span>
                <div>本地区共{{provinceInfo.companyNumber}}家类似条件公司，该公司总资产排名为{{provinceInfo.assetsRank}}位</div>
            </el-card>

            <el-card>
                <span>
                    <el-progress
                        type="dashboard"
                        :percentage="capitalRankdata"
                        color="red"
                        stroke-width="12"
                        width="137"
                        stroke-linecap="butt"
                    ></el-progress>
                </span>
                <div>本地区共{{provinceInfo.companyNumber}}家类似条件公司，该公司注册资产排名为{{provinceInfo.capitalRank}}位</div>
            </el-card>

            <el-card>
                <span>
                    <el-progress
                        type="dashboard"
                        :percentage="dateRankdata"
                        color="green"
                        stroke-width="12"
                        width="137"
                        stroke-linecap="butt"
                    ></el-progress>
                </span>
                <div>本地区共{{provinceInfo.companyNumber}}家类似条件公司，该公司成立日期排名为{{provinceInfo.dateRank}}位</div>
            </el-card>

            <el-card>
                <span>
                    <el-progress
                        type="dashboard"
                        :percentage="profitRankdata"
                        stroke-width="12"
                        width="137"
                        stroke-linecap="butt"
                    ></el-progress>
                </span>
                <div>本地区共{{provinceInfo.companyNumber}}家类似条件公司，该公司利润排名为{{provinceInfo.profitRank}}位</div>
            </el-card>
        </el-drawer>



        <el-drawer  :visible.sync="drawer2" :with-header="false">
            <el-card style="margin-top:10px">
                <div>本公司所属行业: {{industry}} , 该公司名为: {{provinceInfo.companyName}}</div>
            </el-card>

            <el-card style="margin-top:10px">
                <span>
                    <el-progress
                        type="dashboard"
                        :percentage="assetsRankdata2"
                        color="purple"
                        stroke-width="12"
                        width="137"
                        stroke-linecap="butt"
                    ></el-progress>
                </span>
                <div>本行业共{{industryAnalysisInfo.total}}家类似条件公司，该公司总资产排名为{{industryAnalysisInfo.assetsrank}}位</div>
            </el-card>

            <el-card>
                <span>
                    <el-progress
                        type="dashboard"
                        :percentage="capitalRankdata2"
                        color="brown"
                        stroke-width="12"
                        width="137"
                        stroke-linecap="butt"
                    ></el-progress>
                </span>
                <div>本行业共{{industryAnalysisInfo.total}}家类似条件公司，该公司注册资产排名为{{industryAnalysisInfo.capitalrank}}位</div>
            </el-card>

            <el-card>
                <span>
                    <el-progress
                        type="dashboard"
                        :percentage="estabRankdata"
                        color="red"
                        stroke-width="12"
                        width="137"
                        stroke-linecap="butt"
                    ></el-progress>
                </span>
                <div>本行业共{{industryAnalysisInfo.total}}家类似条件公司，该公司成立日期排名为{{industryAnalysisInfo.estabrank}}位</div>
            </el-card>

            <el-card>
                <span>
                    <el-progress
                        type="dashboard"
                        :percentage="profitRankdata2"
                        color="green"
                        stroke-width="12"
                        width="137"
                        stroke-linecap="butt"
                    ></el-progress>
                </span>
                <div>本行业共{{industryAnalysisInfo.total}}家类似条件公司，该公司利润排名为{{industryAnalysisInfo.profitrank}}位</div>
            </el-card>
        </el-drawer>



        <el-card shadow="hover" >
            <div slot="header" class="infotable">
                <span style="font-size:18px ; font-weight: 520">股东信息</span>
                <span class="rowhead">
                    <el-button
                        slot="prepend"
                        icon="el-icon-document-copy"
                        @click="holdercopy()"
                    >一键复制</el-button>
                </span>
            </div>
            <el-col span="16" style="margin-bottom:20px; border:solid ;border-width:1px ; color:gray ; border-radius:10px">
                <el-table
                    :data="toptenholders"
                    stripe
                    style="width: 100%"
                    cell-style="font-weight: 700;"
                >
                    <el-table-column prop="name" label="姓名" width="700"></el-table-column>
                    <el-table-column prop="num" label="持股排名" width="150"></el-table-column>
                    <el-table-column prop="quantity" label="持股数量" width="150"></el-table-column>
                    <el-table-column prop="ratio" label="持股占比"></el-table-column>
                </el-table>
            </el-col>

            <el-col span="7" offset="1">
                <div id="myChart" :style="{width: '500px', height: '500px'}"></div>
            </el-col>
        </el-card>

        <el-card shadow="hover" >
            <div slot="header" class="infotable4">
                <span style="font-size:18px ; font-weight: 520">投标信息</span>
                <span class="rowhead4">
                    <el-button
                        slot="prepend"
                        icon="el-icon-document-copy"
                        @click="biddingcopy()"
                    >一键复制</el-button>
                </span>
            </div>

            <el-col style="margin-bottom:20px ; border:solid ;border-width:1px ; color:gray ;border-radius:10px">
                <el-table
                    :data="bidding_info"
                    stripe
                    style="width: 100%"
                    cell-style="font-weight: 700;"
                >
                    <el-table-column prop="title" label="档案标题" width="650"></el-table-column>
                    <el-table-column prop="date" label="发布时间" width="150"></el-table-column>
                    <el-table-column prop="department" label="发布单位" width="150"></el-table-column>
                    <el-table-column prop="link" label="项目链接"></el-table-column>
                    <el-table-column fixed="right" label="操作" width="250">
                        <template slot-scope="scope">
                            <el-button
                                @click="bidLink(scope.row.link)"
                                type="text"
                                size="small"
                            >点击跳转</el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </el-col>
        </el-card>

        <el-card shadow="hover" >
            <div slot="header" class="infotable5">
                <span style="font-size:18px ; font-weight: 520">专利信息</span>
                <span class="rowhead5">
                    <el-button
                        slot="prepend"
                        icon="el-icon-document-copy"
                        @click="patentcopy()"
                    >一键复制</el-button>
                </span>
            </div>

            <el-col style="margin-bottom:20px ; border:solid ;border-width:1px ; color:gray ;border-radius:10px">
                <el-table
                    :data="patent_info"
                    stripe
                    style="width: 100%"
                    max-height="250"
                    cell-style="font-weight: 700;"
                >
                    <el-table-column prop="title" label="专利名" width="650"></el-table-column>
                    <el-table-column prop="classify" label="专利分类" width="200"></el-table-column>
                    <el-table-column prop="date" label="专利日期" width="150"></el-table-column>
                    <el-table-column prop="link" label="专利内容链接"></el-table-column>
                    <el-table-column fixed="right" label="操作" width="250">
                        <template slot-scope="scope">
                            <el-button
                                @click="bidLink(scope.row.link)"
                                type="text"
                                size="small"
                            >点击跳转</el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </el-col>
        </el-card>

        <el-card shadow="hover">
            <div slot="header" class="infotable6">
                <span style="font-size:18px ; font-weight: 520">企业年报</span>
                <span class="rowhead6">
                    <el-button
                        slot="prepend"
                        icon="el-icon-document-copy"
                        @click="annualcopy()"
                    >一键复制</el-button>
                </span>

                <span style="margin-left:780px ; font-size:18px ; font-weight: 520">高管信息</span>
                <span class="rowhead2">
                    <el-button
                        slot="prepend"
                        icon="el-icon-document-copy"
                        @click="executivecopy()"
                    >一键复制</el-button>
                </span>
            </div>

            <el-row style=" margin-bottom:5px ;border:solid ;border-width:1px ; color:gray ;border-radius:10px">
                <el-col :span="12">
                    <el-table
                        :data="annualReport"
                        stripe
                        style="width: 95%"
                        max-height="432"
                        cell-style="font-weight: 700;"
                    >
                        <el-table-column prop="companyName" label="公司名" width="420"></el-table-column>
                        <el-table-column prop="nianBaoTitle" label="年报标题" width="225"></el-table-column>
                        <el-table-column label="操作">
                            <template slot-scope="scope">
                                <el-button
                                    @click="bidLink(scope.row.nianBaoUrl)"
                                    type="text"
                                    size="small"
                                >点击跳转</el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                </el-col>

                <el-col :span="12">
                    <el-table
                        :data="executives"
                        stripe
                        style="width: 100%"
                        max-height="432"
                        cell-style="font-weight: 700;"
                    >
                        <el-table-column prop="job" label="职位" width="350"></el-table-column>
                        <el-table-column prop="name" label="姓名"></el-table-column>
                    </el-table>
                </el-col>
            </el-row>
        </el-card>

        <el-card shadow="hover">
            <div slot="header" class="infotable6">
                <span style="font-size:18px ; font-weight: 520">分支公司信息</span>
                <span class="rowhead6">
                    <el-button
                        slot="prepend"
                        icon="el-icon-document-copy"
                        @click="branchcopy()"
                    >一键复制</el-button>
                </span>
            </div>

            <el-row style=" margin-bottom:5px ;border:solid ;border-width:1px ; color:gray; border-radius:10px">
                <el-table
                    :data="branchInfo"
                    stripe
                    style="width: 100%"
                    cell-style="font-weight: 700;"
                >
                    <el-table-column prop="title" label="分公司名" width="420"></el-table-column>
                    <el-table-column prop="department" label="认证部门" width="450"></el-table-column>
                    <el-table-column prop="link" label="网址链接" width="450"></el-table-column>
                    <el-table-column label="操作">
                        <template slot-scope="scope">
                            <el-button
                                @click="bidLink(scope.row.link)"
                                type="text"
                                size="small"
                            >点击跳转</el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </el-row>
        </el-card>

        <el-card shadow="hover">
            <div slot="header" class="infotable7">
                <span style="font-size:18px ; font-weight: 520">法院判决信息</span>
                <span class="rowhead7">
                    <el-button
                        slot="prepend"
                        icon="el-icon-document-copy"
                        @click="judgementcopy()"
                    >一键复制</el-button>
                </span>
            </div>

            <el-col style="margin-bottom:20px;border:solid ;border-width:1px ; color:gray ;border-radius:10px">
                <el-table
                    :data="judgement_document"
                    stripe
                    style="width: 100%"
                    max-height="250"
                    cell-style="font-weight: 700;"
                >
                    <el-table-column prop="namelist" label="案件名" width="420"></el-table-column>
                    <el-table-column prop="riqi" label="案件日期" width="150"></el-table-column>
                    <el-table-column prop="court" label="判决法院" width="350"></el-table-column>
                    <el-table-column prop="namelink" label="案件链接"></el-table-column>
                    <el-table-column fixed="right" label="操作" width="515">
                        <template slot-scope="scope">
                            <el-button
                                @click="bidLink(scope.row.namelink)"
                                type="text"
                                size="small"
                            >点击跳转</el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </el-col>
        </el-card>

        <el-card shadow="hover" style="overflow-x:auto;overflow-y:auto;">
            <div slot="header" class="infotable8">
                <span style="font-size:18px ; font-weight: 520">行政表彰处罚信息</span>
                <span class="rowhead8">
                    <el-button slot="prepend" icon="el-icon-document-copy" @click="admincopy()">一键复制</el-button>
                </span>
            </div>

            <el-col style="margin-bottom:20px ; border:solid ;border-width:1px ; color:gray ;border-radius:10px">
                <el-table
                    :data="adminCommen"
                    stripe
                    style="width: 100%"
                    cell-style="font-weight: 700;"
                >
                    <el-table-column prop="title" label="表彰内容" width="420"></el-table-column>
                    <el-table-column prop="date" label="日期" width="150"></el-table-column>
                    <el-table-column prop="department" label="认证部门" width="350"></el-table-column>
                    <el-table-column prop="link" label="相关链接"></el-table-column>
                    <el-table-column fixed="right" label="操作" width="515">
                        <template slot-scope="scope">
                            <el-button
                                @click="bidLink(scope.row.link)"
                                type="text"
                                size="small"
                            >点击跳转</el-button>
                        </template>
                    </el-table-column>
                </el-table>

                <el-table
                    :data="adminPunish"
                    stripe
                    style="width: 100%"
                    cell-style="font-weight: 700;"
                >
                    <el-table-column prop="title" label="处罚内容" width="420"></el-table-column>
                    <el-table-column prop="date" label="日期" width="150"></el-table-column>
                    <el-table-column prop="department" label="认证部门" width="350"></el-table-column>
                    <el-table-column prop="link" label="相关链接"></el-table-column>
                    <el-table-column fixed="right" label="操作" width="515">
                        <template slot-scope="scope">
                            <el-button
                                @click="bidLink(scope.row.link)"
                                type="text"
                                size="small"
                            >点击跳转</el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </el-col>
        </el-card>

        <el-card
            shadow="hover"
            style="overflow-x:auto;overflow-y:auto; margin-top:20px ; border-radius: 20px;"
            class="lastrow"
        >
            <el-col :span="6" :offset="1">
                <span>
                    <i style="font-size:20px" class="el-icon-s-grid"></i>
                </span>
                <span style="margin-left:9px">万家plus企业或组织机构被收录</span>
            </el-col>

            <el-col :span="6">
                <span>
                    <i style="font-size:20px" class="el-icon-s-promotion"></i>
                </span>
                <span style="margin-left:9px">秒速搜索，快速精确响应</span>
            </el-col>

            <el-col :span="6">
                <span>
                    <i style="font-size:20px" class="el-icon-s-marketing"></i>
                </span>
                <span style="margin-left:9px">多维信息，分门别类，立体分析</span>
            </el-col>

            <el-col :span="5">
                <span>
                    <i style="font-size:20px" class="el-icon-s-data"></i>
                </span>
                <span style="margin-left:9px">状态精确展示，助您精准决策</span>
            </el-col>

            <el-divider></el-divider>

            <el-col :span="8" :offset="1">
                <span>
                    <i style="font-size:20px" class="el-icon-s-order"></i>
                </span>
                <span style="margin-left:9px">数据来源:启信宝，天眼查，绿盾，全国企业信用信息公示系统等</span>
            </el-col>

            <el-col :span="4" :offset="2">
                <span>
                    <i style="font-size:20px" class="el-icon-info"></i>
                </span>
                <span style="margin-left:9px">关于我们:</span>
                <el-button
                    style="margin-left:9px ; font-size:15px"
                    type="text"
                    @click="dialogVisible = true"
                >意见反馈</el-button>
            </el-col>

            <el-col :span="6" :offset="3">
                <span>
                    <i style="font-size:20px" class="el-icon-user-solid"></i>
                </span>
                <span style="margin-left:9px">倾力奉献: Debuggers小组</span>
            </el-col>
        </el-card>

        <el-dialog
            title="我们期待得到您的意见"
            :visible.sync="dialogVisible"
            width="30%"
            :before-close="handleClose"
            style="text-align:center"
        >
            <span>反馈内容</span>
            <el-input
                type="textarea"
                :autosize="{ minRows: 2, maxRows: 4}"
                placeholder="在这里留下您的想法"
                v-model="advicearea"
            ></el-input>
            <span>联系方式</span>
            <el-input placeholder="请让我们为您反馈消息" v-model="connectionarea" clearable></el-input>

            <span slot="footer" class="dialog-footer">
                <el-button @click="dialogVisible = false">取消</el-button>
                <el-button type="primary"  @click="sendmessage()">确 定</el-button>
            </span>
        </el-dialog>

        <div style="height: 100px"></div>
    </div>
</template>

<script>
import axios from 'axios';
import Schart from 'vue-schart';
import echarts from 'echarts';
export default {
    created() {
        this.creditCode = this.$route.query.creditCode;
        //this.creditCode = '911101017214323992';
        this.companyName = this.$route.query.companyName;

        var qsbasicinfo = require('qs');
        axios
            .post(
                'http://121.89.181.241:8081/GeneralInfo/getBasicInfo',
                qsbasicinfo.stringify(
                    {
                        creditCode: this.creditCode
                    },
                    { indices: false }
                )
            )

            .then((response) => {
                if (response.data.errcode == '0') {
                    this.companyBasicInfo = response.data.CompanyBasicInfo;
                }
                if (this.companyBasicInfo.industry == '' || this.companyBasicInfo.industry == 'null') {
                    this.companyBasicInfo.industry = '暂无';
                }
                if (this.companyBasicInfo.companyType == '' || this.companyBasicInfo.companyType == 'null') {
                    this.companyBasicInfo.companyType = '暂无';
                }
                if (this.companyBasicInfo.legalRepresentative == '' || this.companyBasicInfo.legalRepresentative == 'null') {
                    this.companyBasicInfo.legalRepresentative = '暂无';
                }
                if (this.companyBasicInfo.estabDate == '' || this.companyBasicInfo.estabDate == 'null') {
                    this.companyBasicInfo.estabDate = '暂无';
                }
                if (this.companyBasicInfo.regCapital == '' || this.companyBasicInfo.regCapital == 'null') {
                    this.companyBasicInfo.regCapital = '暂无';
                }
                if (this.companyBasicInfo.regisAdress == '' || this.companyBasicInfo.regisAdress == 'null') {
                    this.companyBasicInfo.regisAdress = '暂无';
                }
            })
            .catch(function (error) {
                alert(error);
            });

        var qstoptenholders = require('qs');
        axios
            .post(
                'http://121.89.181.241:8081/GeneralInfo/getTopTenHolders',
                qstoptenholders.stringify(
                    {
                        creditCode: this.creditCode
                    },
                    { indices: false }
                )
            )

            .then((response) => {
                if (response.data.errcode == '0') {
                    this.toptenholders = response.data.topTenHolders;
                }
            })
            .catch(function (error) {
                alert(error);
            });

        var qsexecutives = require('qs');
        axios
            .post(
                'http://121.89.181.241:8081/GeneralInfo/getExecutives',
                qsexecutives.stringify(
                    {
                        creditCode: this.creditCode
                    },
                    { indices: false }
                )
            )

            .then((response) => {
                if (response.data.errcode == '0') {
                    this.executives = response.data.executives;
                }
            })
            .catch(function (error) {
                alert(error);
            });

        var qsfinance = require('qs');
        axios
            .post(
                'http://121.89.181.241:8081/GeneralInfo/getFinance',
                qsfinance.stringify(
                    {
                        creditCode: this.creditCode
                    },
                    { indices: false }
                )
            )

            .then((response) => {
                if (response.data.errcode == '0') {
                    this.finance = response.data.finance;
                }
                if (this.finance.income == 'null' || this.finance.income == '') this.finance.income = '暂无';
                if (this.finance.totalAssets == 'null' || this.finance.totalAssets == '') this.finance.totalAssets = '暂无';
                if (this.finance.netAssets == 'null' || this.finance.netAssets == '') this.finance.netAssets = '暂无';
                if (this.finance.totalLiability == 'null' || this.finance.totalLiability == '') this.finance.totalLiability = '暂无';
                if (this.finance.profit == 'null' || this.finance.profit == '') this.finance.profit = '暂无';
                if (this.finance.netProfit == 'null' || this.finance.netProfit == '') this.finance.netProfit = '暂无';
            })

            .catch(function (error) {
                alert(error);
            });

        var qsbiddinginfo = require('qs');
        axios
            .post(
                'http://121.89.181.241:8081/MainInfo/getBidInfo',
                qsbiddinginfo.stringify(
                    {
                        creditCode: this.creditCode
                    },
                    { indices: false }
                )
            )

            .then((response) => {
                if (response.data.errcode == '0') {
                    this.bidding_info = response.data.bidding_info;
                }
                if (this.bidding_info.title == 'null' || this.bidding_info.title == '') this.bidding_info.title = '暂无';
                if (this.bidding_info.date == 'null' || this.bidding_info.date == '') this.bidding_info.date = '暂无';
                if (this.bidding_info.department == 'null' || this.bidding_info.department == '') this.bidding_info.department = '暂无';
                if (this.bidding_info.link == 'null' || this.bidding_info.link == '') this.bidding_info.link = '暂无';
            })

            .catch(function (error) {
                alert(error);
            });

        var qsadmincommen = require('qs');
        axios
            .post(
                'http://121.89.181.241:8081/MainInfo/getAdminCommen',
                qsadmincommen.stringify(
                    {
                        creditCode: this.creditCode
                    },
                    { indices: false }
                )
            )

            .then((response) => {
                if (response.data.errcode == '0') {
                    this.adminCommen = response.data.adminCommen;
                }
                if (this.adminCommen.title == 'null' || this.adminCommen.title == '') this.adminCommen.title = '暂无';
                if (this.adminCommen.date == 'null' || this.adminCommen.date == '') this.adminCommen.date = '暂无';
                if (this.adminCommen.department == 'null' || this.adminCommen.department == '') this.adminCommen.department = '暂无';
                if (this.adminCommen.link == 'null' || this.adminCommen.link == '') this.adminCommen.link = '暂无';
            })

            .catch(function (error) {
                alert(error);
            });

        var qspunish = require('qs');
        axios
            .post(
                'http://121.89.181.241:8081/MainInfo/getAdminPunish',
                qspunish.stringify(
                    {
                        creditCode: this.creditCode
                    },
                    { indices: false }
                )
            )

            .then((response) => {
                if (response.data.errcode == '0') {
                    this.adminPunish = response.data.adminPunish;
                }
                if (this.adminPunish.title == 'null' || this.adminPunish.title == '') this.adminPunish.title = '暂无';
                if (this.adminPunish.date == 'null' || this.adminPunish.date == '') this.adminPunish.date = '暂无';
                if (this.adminPunish.department == 'null' || this.adminPunish.department == '') this.adminPunish.department = '暂无';
                if (this.adminPunish.link == 'null' || this.adminPunish.link == '') this.adminPunish.link = '暂无';
            })

            .catch(function (error) {
                alert(error);
            });

        var qspatentinfo = require('qs');
        axios
            .post(
                'http://121.89.181.241:8081/MainInfo/getPatentInfo',
                qspatentinfo.stringify(
                    {
                        creditCode: this.creditCode
                    },
                    { indices: false }
                )
            )

            .then((response) => {
                if (response.data.errcode == '0') {
                    this.patent_info = response.data.patent_info;
                }
                if (this.patent_info.title == 'null' || this.patent_info.title == '') this.patent_info.title = '暂无';
                if (this.patent_info.classify == 'null' || this.patent_info.classify == '') this.patent_info.classify = '暂无';
                if (this.patent_info.date == 'null' || this.patent_info.date == '') this.patent_info.date = '暂无';
                if (this.patent_info.link == 'null' || this.patent_info.link == '') this.patent_info.link = '暂无';
            })

            .catch(function (error) {
                alert(error);
            });

        var qsannualreport = require('qs');
        axios
            .post(
                'http://121.89.181.241:8081/MainInfo/getAnualReport',
                qsannualreport.stringify(
                    {
                        creditCode: this.creditCode
                    },
                    { indices: false }
                )
            )

            .then((response) => {
                if (response.data.errcode == '0') {
                    this.annualReport = response.data.annualReport;
                }
                if (this.annualReport.companyName == 'null' || this.annualReport.companyName == '') this.annualReport.companyName = '暂无';
                if (this.annualReport.nianBaoTitle == 'null' || this.annualReport.nianBaoTitle == '')
                    this.annualReport.nianBaoTitle = '暂无';
                if (this.annualReport.nianBaoUrl == 'null' || this.annualReport.nianBaoUrl == '') this.annualReport.nianBaoUrl = '暂无';
            })

            .catch(function (error) {
                alert(error);
            });

        var qsjudge = require('qs');
        axios
            .post(
                'http://121.89.181.241:8081/MainInfo/getJudgementDocument',
                qsjudge.stringify(
                    {
                        creditCode: this.creditCode
                    },
                    { indices: false }
                )
            )

            .then((response) => {
                if (response.data.errcode == '0') {
                    this.judgement_document = response.data.judgement_document;
                }
                if (this.judgement_document.namelist == 'null' || this.judgement_document.namelist == '')
                    this.judgement_document.namelist = '暂无';
                if (this.judgement_document.court == 'null' || this.judgement_document.court == '') this.judgement_document.court = '暂无';
                if (this.judgement_document.riqi == 'null' || this.judgement_document.riqi == '') this.judgement_document.riqi = '暂无';
                if (this.judgement_document.namelink == 'null' || this.judgement_document.namelink == '')
                    this.judgement_document.namelink = '暂无';
            })

            .catch(function (error) {
                alert(error);
            });

        var qsbranch = require('qs');
        axios
            .post(
                'http://121.89.181.241:8081/MainInfo/getBranchInfo',
                qsbranch.stringify(
                    {
                        creditCode: this.creditCode
                    },
                    { indices: false }
                )
            )

            .then((response) => {
                if (response.data.errcode == '0') {
                    this.branchInfo = response.data.branchInfo;
                }
                if (this.branchInfo.title == 'null' || this.branchInfo.title == '') this.branchInfo.title = '暂无';
                if (this.branchInfo.department == 'null' || this.branchInfo.department == '') this.branchInfo.department = '暂无';
                if (this.branchInfo.link == 'null' || this.branchInfo.link == '') this.branchInfo.link = '暂无';
            })

            .catch(function (error) {
                alert(error);
            });

        var qsrank = require('qs');
        axios
            .post(
                'http://121.89.181.241:8081/Analysis/getProvinceInfo',
                qsrank.stringify(
                    {
                        creditCode: this.creditCode
                    },
                    { indices: false }
                )
            )

            .then((response) => {
                this.provinceInfo = response.data.provinceInfo;
                this.assetsRankdata = Math.ceil((response.data.provinceInfo.assetsRank / response.data.provinceInfo.companyNumber) * 100);
                this.capitalRankdata = Math.ceil((response.data.provinceInfo.capitalRank / response.data.provinceInfo.companyNumber) * 100);
                this.dateRankdata = Math.ceil((response.data.provinceInfo.dateRank / response.data.provinceInfo.companyNumber) * 100);
                this.profitRankdata = Math.ceil((response.data.provinceInfo.profitRank / response.data.provinceInfo.companyNumber) * 100);
            })

            .catch(function (error) {
                alert(error);
            });


            var qsrank2 = require('qs');
        axios
            .post(
                'http://121.89.181.241:8081/Analysis/getIndustryAnalysisInfo',
                qsrank2.stringify(
                    {
                        creditCode: this.creditCode
                    },
                    { indices: false }
                )
            )

            .then((response) => {
                this.industry = response.data.industry;
                this.industryAnalysisInfo = response.data.industryAnalysisInfo;
                this.assetsRankdata2 = Math.ceil((response.data.industryAnalysisInfo.assetsrank / response.data.industryAnalysisInfo.total) * 100);
                this.capitalRankdata2 = Math.ceil((response.data.industryAnalysisInfo.capitalrank / response.data.industryAnalysisInfo.total) * 100);
                this.estabRankdata = Math.ceil((response.data.industryAnalysisInfo.estabrank / response.data.industryAnalysisInfo.total) * 100);
                this.profitRankdata2 = Math.ceil((response.data.industryAnalysisInfo.profitrank / response.data.industryAnalysisInfo.total) * 100);
            })

            .catch(function (error) {
                alert(error);
            });

    },
    data() {
        return {
            search_text: '',
            chosenTab: 'all',
            companyName: '',

            creditCode: '',

            advicearea: '',

            connectionarea: '',

            dialogVisible: false,

            myChart: null,

            chartPie: null,

            drawer: false,
            drawer2: false,

            assetsRankdata: 0,
            capitalRankdata: 0,
            dateRankdata: 0,
            profitRankdata: 0,

            provinceInfo: [],

            industry: null,

            assetsRankdata2: 0,
            capitalRankdata2: 0,
            estabRankdata: 0,
            profitRankdata2: 0,

            screenHeight: document.body.clientHeight,

            industryAnalysisInfo: [],

            companyBasicInfo: [],

            toptenholders: [],

            executives: [],

            finance: [],

            bidding_info: [],

            patent_info: [],

            annualReport: [],

            judgement_document: [],

            adminCommen: [],

            adminPunish: [],

            branchInfo: []
        };
    },

    mounted() {


        const that = this
        window.onresize = () => {
        return (() => {
        window.screenHeight = document.body.clientHeight
        that.screenHeight = window.screenHeight
        })()
        }

        this.initData();
        this.drawpie();

    },

    methods: {
        handleClose(done) {
            this.$confirm('确认关闭？')
                .then((_) => {
                    done();
                })
                .catch((_) => {});
        },

        drawpie() {
            //console.log(this.pieData);
            // 基于准备好的dom，初始化echarts实例
            this.myChart = this.$echarts.init(document.getElementById('myChart'));
            // 绘制图表
            myChart.setOption({
                backgroundColor: '#2c343c',

                title: {
                    text: 'Customized Pie',
                    left: 'center',
                    top: 20,
                    textStyle: {
                        color: '#ccc'
                    }
                },

                tooltip: {
                    trigger: 'item',
                    formatter: '{a} <br/>{b} : {c} ({d}%)'
                },

                visualMap: {
                    show: false,
                    min: 80,
                    max: 600,
                    inRange: {
                        colorLightness: [0, 1]
                    }
                },
                series: [
                    {
                        name: '访问来源',
                        type: 'pie',
                        radius: '55%',
                        center: ['50%', '50%'],
                        data: [],
                        roseType: 'radius',
                        label: {
                            color: 'rgba(255, 255, 255, 0.3)'
                        },
                        labelLine: {
                            lineStyle: {
                                color: 'rgba(255, 255, 255, 0.3)'
                            },
                            smooth: 0.2,
                            length: 10,
                            length2: 20
                        },
                        itemStyle: {
                            color: '#c23531',
                            shadowBlur: 200,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        },

                        animationType: 'scale',
                        animationEasing: 'elasticOut',
                        animationDelay: function (idx) {
                            return Math.random() * 200;
                        }
                    }
                ]
            });
        },
        async initData() {
            var qstoptenholders = require('qs');
            var res = await axios.post(
                'http://121.89.181.241:8081/GeneralInfo/getTopTenHolders',
                qstoptenholders.stringify(
                    {
                        creditCode: this.creditCode
                    },
                    { indices: false }
                )
            );
            //console.log(res.data);
            var getData = [];
            //先进行赋值
            //console.log(res.data.topTenHolders.length);
            for (let i = 0; i < res.data.topTenHolders.length; i++) {
                var obj = new Object();
                obj.name = res.data.topTenHolders[i].name;
                obj.value = res.data.topTenHolders[i].quantity;
                getData[i] = obj;
                //console.log(i);
            }
            console.log(getData);
            this.myChart.setOption({
                tooltip: {
                    trigger: 'item',
                    formatter: '{b} : {c} ({d}%)'
                },

                series: [
                    {
                        type: 'pie',
                        data: getData
                    }
                ]
            });
        },

        search() {
            //console.log(this.search_text);
            if (this.search_text)
                //传值并跳转到下个页面 下个页面必须要接受不然会卡死
                this.$router.push({ path: '/list', query: { inputText: this.search_text, chosen: this.chosenTab } });
            //直接跳转网页
            //this.$router.push('/list');
            else {
                this.$message.error('请输入搜索信息');
            }
        },

        openwebsite() {
            if (this.companyBasicInfo.website.search('http://') != -1) {
                window.open(this.companyBasicInfo.website);
            } else {
                window.open('http://' + this.companyBasicInfo.website);
            }
        },

        annualLink(url) {
            window.open(url);
        },

        bidLink(url) {
            window.open(url);
        },

        handleClick() {
            console.log(this.activeName);
        },
        holdercopy: function () {
            var cptext = '股东信息\n';
            var x;
            for (x in this.toptenholders) {
                cptext += '姓名 : ';
                cptext += JSON.stringify(this.toptenholders[x].name);
                cptext += '\t';
                cptext += '持股排名 : ';
                cptext += JSON.stringify(this.toptenholders[x].num);
                cptext += '\t';
                cptext += '持股数量 : ';
                cptext += JSON.stringify(this.toptenholders[x].quantity);
                cptext += '\t';
                cptext += '持股占比 : ';
                cptext += JSON.stringify(this.toptenholders[x].ratio);
                cptext += '\t\n';
                cptext = cptext.replace(/\"/g, '');
            }
            this.$copyText(cptext).then(
                (e) => {
                    this.$message.success('复制成功!');
                    console.log(e);
                },
                (e) => {
                    this.$message.error('复制失败!');
                    console.log(e);
                }
            );
        },
        executivecopy: function () {
            var cptext = '高管信息\n';
            var x;
            for (x in this.executives) {
                cptext += '公司名 : ';
                cptext += JSON.stringify(this.executives[x].companyName);
                cptext += '\t';
                cptext += '社会信用代码 : ';
                cptext += JSON.stringify(this.executives[x].creditCode);
                cptext += '\t';
                cptext += '职位 : ';
                cptext += JSON.stringify(this.executives[x].job);
                cptext += '\t';
                cptext += '姓名 : ';
                cptext += JSON.stringify(this.executives[x].name);
                cptext += '\t\n';
                cptext = cptext.replace(/\"/g, '');
            }
            this.$copyText(cptext).then(
                (e) => {
                    this.$message.success('复制成功!');
                    console.log(e);
                },
                (e) => {
                    this.$message.error('复制失败!');
                    console.log(e);
                }
            );
        },

        branchcopy: function () {
            var cptext = '分支公司信息\n';
            var x;
            for (x in this.branchInfo) {
                cptext += '分公司名 : ';
                cptext += JSON.stringify(this.branchInfo[x].title);
                cptext += '\t';
                cptext += '认证部门 : ';
                cptext += JSON.stringify(this.branchInfo[x].department);
                cptext += '\t';
                cptext += '网址链接 : ';
                cptext += JSON.stringify(this.branchInfo[x].link);
                cptext += '\t\n';
                cptext = cptext.replace(/\"/g, '');
            }
            this.$copyText(cptext).then(
                (e) => {
                    this.$message.success('复制成功!');
                    console.log(e);
                },
                (e) => {
                    this.$message.error('复制失败!');
                    console.log(e);
                }
            );
        },

        financecopy: function () {
            var cptext = '财务数据\n';
            var x;
            for (x in this.finance) {
                cptext += '收入 : ';
                cptext += JSON.stringify(this.finance[x].income);
                cptext += '\t';
                cptext += '公司总资产 : ';
                cptext += JSON.stringify(this.finance[x].totalAssets);
                cptext += '\t';
                cptext += '公司净资产 : ';
                cptext += JSON.stringify(this.finance[x].netAssets);
                cptext += '\t';
                cptext += '公司总负债 : ';
                cptext += JSON.stringify(this.finance[x].totalLiability);
                cptext += '\t';
                cptext += '公司营业利润 : ';
                cptext += JSON.stringify(this.finance[x].profit);
                cptext += '\t';
                cptext += '公司净利润 : ';
                cptext += JSON.stringify(this.finance[x].netProfit);
                cptext += '\t\n';
                cptext = cptext.replace(/\"/g, '');
            }
            this.$copyText(cptext).then(
                (e) => {
                    this.$message.success('复制成功!');
                    console.log(e);
                },
                (e) => {
                    this.$message.error('复制失败!');
                    console.log(e);
                }
            );
        },

        biddingcopy: function () {
            var cptext = '投标信息\n';
            var x;
            for (x in this.bidding_info) {
                cptext += '档案标题 : ';
                cptext += JSON.stringify(this.bidding_info[x].title);
                cptext += '\t';
                cptext += '发布日期 : ';
                cptext += JSON.stringify(this.bidding_info[x].date);
                cptext += '\t';
                cptext += '发布单位 : ';
                cptext += JSON.stringify(this.bidding_info[x].department);
                cptext += '\t';
                cptext += '项目链接 : ';
                cptext += JSON.stringify(this.bidding_info[x].link);
                cptext += '\t\n';
                cptext = cptext.replace(/\"/g, '');
            }
            this.$copyText(cptext).then(
                (e) => {
                    this.$message.success('复制成功!');
                    console.log(e);
                },
                (e) => {
                    this.$message.error('复制失败!');
                    console.log(e);
                }
            );
        },

        patentcopy: function () {
            var cptext = '专利信息\n';
            var x;
            for (x in this.patent_info) {
                cptext += '专利名 : ';
                cptext += JSON.stringify(this.patent_info[x].title);
                cptext += '\t';
                cptext += '专利分类 : ';
                cptext += JSON.stringify(this.patent_info[x].classify);
                cptext += '\t';
                cptext += '专利日期 : ';
                cptext += JSON.stringify(this.patent_info[x].date);
                cptext += '\t';
                cptext += '专利内容链接 : ';
                cptext += JSON.stringify(this.patent_info[x].link);
                cptext += '\t\n';
                cptext = cptext.replace(/\"/g, '');
            }
            this.$copyText(cptext).then(
                (e) => {
                    this.$message.success('复制成功!');
                    console.log(e);
                },
                (e) => {
                    this.$message.error('复制失败!');
                    console.log(e);
                }
            );
        },

        annualcopy: function () {
            var cptext = '企业年报\n';
            var x;
            for (x in this.annualReport) {
                cptext += '公司名 : ';
                cptext += JSON.stringify(this.annualReport[x].companyName);
                cptext += '\t';
                cptext += '年报标题 : ';
                cptext += JSON.stringify(this.annualReport[x].nianBaoTitle);
                cptext += '\t';
                cptext += '年报链接 : ';
                cptext += JSON.stringify(this.annualReport[x].nianBaoUrl);
                cptext += '\t\n';
                cptext = cptext.replace(/\"/g, '');
            }
            this.$copyText(cptext).then(
                (e) => {
                    this.$message.success('复制成功!');
                    console.log(e);
                },
                (e) => {
                    this.$message.error('复制失败!');
                    console.log(e);
                }
            );
        },

        admincopy: function () {
            var cptext = '行政表彰处罚信息\n';
            var x;
            var y;
            for (x in this.adminCommen) {
                cptext += '表彰内容: ';
                cptext += JSON.stringify(this.adminCommen[x].title);
                cptext += '\t';
                cptext += '日期 : ';
                cptext += JSON.stringify(this.adminCommen[x].date);
                cptext += '\t';
                cptext += '认证部门 : ';
                cptext += JSON.stringify(this.adminCommen[x].department);
                cptext += '\t';
                cptext += '相关链接 : ';
                cptext += JSON.stringify(this.adminCommen[x].link);
                cptext += '\t\n';
                cptext = cptext.replace(/\"/g, '');
            }

            for (y in this.adminPunish) {
                cptext += '处罚内容: ';
                cptext += JSON.stringify(this.adminPunish[y].title);
                cptext += '\t';
                cptext += '日期 : ';
                cptext += JSON.stringify(this.adminPunish[y].date);
                cptext += '\t';
                cptext += '认证部门 : ';
                cptext += JSON.stringify(this.adminPunish[y].department);
                cptext += '\t';
                cptext += '相关链接 : ';
                cptext += JSON.stringify(this.adminPunish[y].link);
                cptext += '\t\n';
                cptext = cptext.replace(/\"/g, '');
            }
            this.$copyText(cptext).then(
                (e) => {
                    this.$message.success('复制成功!');
                    console.log(e);
                },
                (e) => {
                    this.$message.error('复制失败!');
                    console.log(e);
                }
            );
        },

        judgementcopy: function () {
            var cptext = '法院判决信息\n';
            var x;
            for (x in this.judgement_document) {
                cptext += '案件名 : ';
                cptext += JSON.stringify(this.judgement_document[x].namelist);
                cptext += '\t';
                cptext += '判决法院 : ';
                cptext += JSON.stringify(this.judgement_document[x].court);
                cptext += '\t';
                cptext += '案件日期: ';
                cptext += JSON.stringify(this.judgement_document[x].riqi);
                cptext += '\t';
                cptext += '案件链接 : ';
                cptext += JSON.stringify(this.judgement_document[x].namelink);
                cptext += '\t\n';
                cptext = cptext.replace(/\"/g, '');
            }

            this.$copyText(cptext).then(
                (e) => {
                    this.$message.success('复制成功!');
                    console.log(e);
                },
                (e) => {
                    this.$message.error('复制失败!');
                    console.log(e);
                }
            );
        },

        clientcopy: function () {
            var cptext = '客户信息\n';
            var x;
            for (x in this.client_info) {
                cptext += '客户名字 : ';
                cptext += JSON.stringify(this.client_info[x].name);
                cptext += '\t';
                cptext += '销售占比 : ';
                cptext += JSON.stringify(this.client_info[x].proportion);
                cptext += '\t';
                cptext += '销售金额（万元）: ';
                cptext += JSON.stringify(this.client_info[x].amount);
                cptext += '\t';
                cptext += '报告期 : ';
                cptext += JSON.stringify(this.client_info[x].date);
                cptext += '\t';
                cptext += '数据来源 : ';
                cptext += JSON.stringify(this.client_info[x].source);
                cptext += '\t';
                cptext += '关联关系 : ';
                cptext += JSON.stringify(this.client_info[x].association);
                cptext += '\t\n';
                cptext = cptext.replace(/\"/g, '');
            }

            this.$copyText(cptext).then(
                (e) => {
                    this.$message.success('复制成功!');
                    console.log(e);
                },
                (e) => {
                    this.$message.error('复制失败!');
                    console.log(e);
                }
            );
        },

        newscopy: function () {
            var cptext = '新闻信息\n';
            var x;
            for (x in this.news_info) {
                cptext += '新闻标题 : ';
                cptext += JSON.stringify(this.news_info[x].title);
                cptext += '\t';
                cptext += '发布日期 : ';
                cptext += JSON.stringify(this.news_info[x].date);
                cptext += '\t';
                cptext += '新闻来源 : ';
                cptext += JSON.stringify(this.news_info[x].source);
                cptext += '\t';
                cptext += '新闻链接URL : ';
                cptext += JSON.stringify(this.news_info[x].linkURL);
                cptext += '\t\n';
                cptext = cptext.replace(/\"/g, '');
            }
            this.$copyText(cptext).then(
                (e) => {
                    this.$message.success('复制成功!');
                    console.log(e);
                },
                (e) => {
                    this.$message.error('复制失败!');
                    console.log(e);
                }
            );
        },

        sendmessage: function(){
               var qssuggest = require('qs');
        axios
            .post(
                'http://121.89.181.241:8081/Feedback/advice',
                qssuggest.stringify(
                    {
                        advicearea: this.advicearea,
                        connectionarea: this.connectionarea
                    },
                    { indices: false }
                )
            )

            .then((response) => {
                if (response.data.errcode == '0') {
                    this.$message.success('保存成功!');
                    this.dialogVisible = false;
                }
                if (response.data.errcode == '70002') {
                    this.$message.error('反馈意见联系方式不能为空');
                    //this.dialogVisible = false;
                }
                if (response.data.errcode == '70001') {
                    this.$message.error('反馈意见不能为空');
                    //this.dialogVisible = false;
                }
            
            })

            .catch(function (error) {
                alert(error);
            });
        }
    }
};
</script>



<style>
.el-scrollbar__wrap {
    overflow-x: hidden;
}
.el-tabs__item {
    color: coral;
}
.logo {
    width: 210px;
}
.list_1_row {
    /* background-color: rgba(0, 0, 0, 0.705); */
    background-image: linear-gradient(to right, rgb(20, 129, 148), rgb(106, 87, 180));
    border-radius: 20px;
}
.logoimage {
    display: cover;
    width: 100%;
    width: 200px;
    height: 124px;
}
.ListsearchItem {
    padding: 15px 12px 0px 12px;
    margin-top: 0px;
    margin-bottom: 50px;
    top: 20%;
}

.firstRow .info {
    /* background-color: rgb(69, 101, 143); */
    background-image: linear-gradient(to left, rgb(116, 216, 219), rgb(1, 126, 148));
    border-radius: 20px;
}

.firstRow .first_row {
    margin-top: 0px;
    font-size: 20px;
    color: whitesmoke;
}

.firstRow .row1 {
    /* color: rgb(230, 161, 15);
    border:rgb(37, 230, 11) 1px dashed ; */
    font-size: 20px;
    color: whitesmoke;
}

.firstRow .row2 {
    /* color: rgb(230, 161, 15); */
    margin-left: 50px;
    font-size: 20px;
    color: whitesmoke;
    /* border:rgb(37, 230, 11) 1px dashed ; */
}

.firstRow .row3 {
    /* color: rgb(230, 161, 15); */
    font-size: 20px;
    color: whitesmoke;
    /* border:rgb(37, 230, 11) 1px dashed ; */
}

.firstRow .row4  {
    font-size: 20px;
    color: whitesmoke;
}

.firstRow .row4 .website{
    text-decoration: underline;
}

.infotable {
    height: 20px;
    margin-top: -10px;
}

.infotable2 {
    height: 20px;
    margin-top: -10px;
}

.infotable3 {
    height: 20px;
    margin-top: -10px;
}

.infotable4 {
    height: 20px;
    margin-top: -10px;
}

.infotable5 {
    height: 20px;
    margin-top: -10px;
}

.infotable6 {
    height: 20px;
    margin-top: -10px;
}

.infotable7 {
    height: 20px;
    margin-top: -10px;
}

.infotable8 {
    height: 20px;
    margin-top: -10px;
}

.infotable9 {
    height: 20px;
    margin-top: -10px;
}

.rowhead {
    margin-left: 25px;
}

.rowhead2 {
    margin-left: 25px;
}

.rowhead3 {
    margin-left: 25px;
}

.rowhead4 {
    margin-left: 25px;
}

.rowhead5 {
    margin-left: 25px;
}

.rowhead6 {
    margin-left: 25px;
}

.rowhead7 {
    margin-left: 25px;
}

.rowhead8 {
    margin-left: 25px;
}

.rowhead9 {
    margin-left: 25px;
}

.infotablerowone {
    height: 40px;
    border-radius: 5px 5px;
    border-style: solid;
    border-width: 2px;
    border-color: rgb(69, 101, 143);
    padding-top: 5px;
    border-bottom-width: 0.5px;
}

.infotablerowtwo {
    height: 40px;
    border-radius: 5px 5px;
    border-style: solid;
    border-width: 2px;
    border-color: rgb(69, 101, 143);
    padding-top: 5px;
    border-bottom-width: 0.5px;
}

.infotablerowthree {
    height: 40px;
    border-radius: 5px 5px;
    border-style: solid;
    border-width: 2px;
    border-color: rgb(69, 101, 143);
    padding-top: 5px;
    border-bottom-width: 1px;
}

.infotablerowfour {
    height: 40px;
    border-radius: 5px 5px;
    border-style: solid;
    border-width: 2px;
    border-color: rgb(69, 101, 143);
    padding-top: 5px;
}

.infotablerowfive {
    height: 40px;
    border-radius: 5px 5px;
    border-style: solid;
    border-width: 2px;
    border-color: rgb(69, 101, 143);
    padding-top: 5px;
}

.infotablerowsix {
    height: 40px;
    border-radius: 5px 5px;
    border-style: solid;
    border-width: 2px;
    border-color: rgb(69, 101, 143);
    padding-top: 5px;
}

.infotablerowseven {
    height: 40px;
    border-radius: 5px 5px;
    border-style: solid;
    border-width: 2px;
    border-color: rgb(69, 101, 143);
    padding-top: 5px;
}

.infotableroweight {
    height: 40px;
    border-radius: 5px 5px;
    border-style: solid;
    border-width: 2px;
    border-color: rgb(69, 101, 143);
    padding-top: 5px;
}

.infotablerownine {
    height: 40px;
    border-radius: 5px 5px;
    border-style: solid;
    border-width: 2px;
    border-color: rgb(69, 101, 143);
    padding-top: 5px;
}

.infotablerowone .first {
    margin-left: 10px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowone .second {
    margin-left: 150px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowone .third {
    margin-left: 150px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowone .forth {
    margin-left: 150px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowtwo .first {
    margin-left: 10px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowtwo .second {
    margin-left: 120px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowtwo .third {
    margin-left: 120px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowtwo .forth {
    margin-left: 120px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowthree .first {
    margin-left: 10px;
    padding-left: 10px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowthree .second {
    margin-left: 20px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowthree .third {
    margin-left: 20px;
    padding-left: 20px;

    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowthree .forth {
    margin-left: 20px;
    padding-left: 20px;

    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowthree .fifth {
    margin-left: 20px;
    padding-left: 20px;

    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowthree .sixth {
    margin-left: 20px;
    padding-left: 20px;

    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowfour .first {
    margin-left: 10px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowfour .second {
    margin-left: 150px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowfour .third {
    margin-left: 150px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowfour .forth {
    margin-left: 150px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowfive .first {
    margin-left: 10px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowfive .second {
    margin-left: 50px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowfive .third {
    margin-left: 50px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowfive .forth {
    margin-left: 50px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowsix .first {
    margin-left: 10px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowsix .second {
    margin-left: 125px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowsix .third {
    margin-left: 25px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowseven .first {
    margin-left: 10px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowseven .second {
    margin-left: 120px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowseven .third {
    margin-left: 120px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerowseven .forth {
    margin-left: 120px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotableroweight .first {
    margin-left: 10px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotableroweight .second {
    margin-left: 120px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotableroweight .third {
    margin-left: 120px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotableroweight .forth {
    margin-left: 120px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotableroweight .fifth {
    margin-left: 120px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotableroweight .sixth {
    margin-left: 120px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerownine .first {
    margin-left: 10px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerownine .second {
    margin-left: 250px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerownine .third {
    margin-left: 250px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.infotablerownine .forth {
    margin-left: 300px;
    padding-left: 20px;
    border-left: 5px solid rgb(218, 203, 3);
}

.lastrow {
    background-image: linear-gradient(to right, rgb(34, 173, 197), rgb(161, 245, 241));
}
</style>