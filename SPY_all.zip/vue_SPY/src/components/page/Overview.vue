<template>
<div class="allview">
<div>
<el-row>
    <el-col span="7" class="left_up">
        <div class="Otable_d">
            <h3 class="Otitle">市场总貌</h3>
            <el-table
            :data="tableDataA"
            stripe
            border
            style="width: 100%"
            class="Otable">
            <el-table-column
            prop="num"
            label="证券数量(只)">
            </el-table-column>
            <el-table-column
            prop="all"
            label="总股本(亿股)">
            </el-table-column>
            <el-table-column
            prop="flow"
            label="流通股本(亿股)">
            </el-table-column>
            <el-table-column
            prop="exchange"
            label="成交股数(万股)">
            </el-table-column>
            <el-table-column
            prop="money"
            label="成交金额(万元)">
            </el-table-column>
            </el-table>
        </div>
        <div class="Otable_d Otable_b">
            <h3 class="Otitle">挂牌公司</h3>
            <el-table
            :data="tableDataB"
            stripe
            style="width: 100%"
            class="Otable">
            <el-table-column
            prop="num"
            label="数量(只)">
            </el-table-column>
            <el-table-column
            prop="all"
            label="总股本(亿股)">
            </el-table-column>
            <el-table-column
            prop="flow"
            label="流通股本(亿股)">
            </el-table-column>
            <el-table-column
            prop="exchange"
            label="成交股数(万股)">
            </el-table-column>
            <el-table-column
            prop="money"
            label="成交金额(万元)">
            </el-table-column>
            </el-table>
        </div>
        
    </el-col>
    <el-col span="10">
        <div class="echarts">
            <h1 class="OTitle" align="center"> 市场总览 </h1>
            <div class="mapChart">
              <div :style="{height:'400px',width:'100%'}" ref="myEchart"></div>
            </div>
        </div>
    </el-col>
    <el-col span="6">
      <div class="pieChart">
           <div id="myChart" :style="{width: '100%', height: '400px'}"></div>
        </div>
    </el-col>
</el-row>
<el-row style="margin-top: 30px;">
  <el-col span="8">
    <div class="Otable_d Otable_p">
            <h3 class="Otitle">总资产top5</h3>
            <el-table
            :data="table_1_CA"
            stripe
            border
            style="width: 100%"
            class="Otable_2">
            <el-table-column
            type="index"
            width="50">
            </el-table-column>
            <el-table-column
            prop="name"
            label="公司名">
            </el-table-column>
            <el-table-column
            prop="capital"
            label="总资产(万元)">
            </el-table-column>
            </el-table>
        </div>
  </el-col>
  <el-col span="8">
    <div class="Otable_d Otable_p">
            <h3 class="Otitle">营收能力top5</h3>
            <el-table
            :data="table_2_CA"
            stripe
            border
            style="width: 100%"
            class="Otable_2">
            <el-table-column
            type="index"
            width="50">
            </el-table-column>
            <el-table-column
            prop="name"
            label="公司名">
            </el-table-column>
            <el-table-column
            prop="capital"
            label="净利润(万元)">
            </el-table-column>
            </el-table>
        </div>
  </el-col>
  <el-col span="8">
    <div class="Otable_d Otable_p">
            <h3 class="Otitle">最早注册公司top5</h3>
            <el-table
            :data="table_3_CA"
            stripe
            border
            style="width: 100%"
            class="Otable_2">
            <el-table-column
            type="index"
            width="50">
            </el-table-column>
            <el-table-column
            prop="name"
            label="公司名">
            </el-table-column>
            <el-table-column
            prop="capital"
            label="注册时间">
            </el-table-column>
            </el-table>
        </div>
  </el-col>
</el-row>
<div style="height:800px;"> 
        </div>
</div>
</div>
</template>

<script>
import axios from 'axios';
import Schart from 'vue-schart';
import echarts from 'echarts';
import $ from 'jquery';
import '../../../node_modules/echarts/map/js/china.js' // 引入中国地图数据
export default {
    created() {
      axios.get(this.SERVICE_PATH + "marketOverview.json")
        .then(
            response=>{
            this.tableDataA = response.data.overview;
        })
        .catch(err=>{
            console.log(err)
        });
      axios.get(this.SERVICE_PATH + "listedCompany.json")
        .then(
            response=>{
            this.tableDataB = response.data.overview;
        })
        .catch(err=>{
            console.log(err)
        });
    },
    name: "echarts",
    props: ["userJson"],
    data() {
      return {
        chart: null,
        myChart: null,
        tableDataA: [],
        tableDataB: [],
        table_1_CA: [
          {
            name: "合肥华升泵阀股份有限公司",
            capital : "99970973.98"
          },
          {
            name: "青岛利和萃取股份有限公司",
            capital : "99851647.06"
          },
          {
            name: "门对门网络科技股份有限公司",
            capital : "99836754.16"
          },
          {
            name: "天津联博化工股份有限公司",
            capital : "99785159.18"
          },
          {
            name: "合肥志诚教育股份有限公司",
            capital : "99763070.07"
          },
        ],
        table_2_CA: [
          {
            name: "湖南恒光科技股份有限公司",
            capital : "99934840.69"
          },
          {
            name: "海宁宏大小额贷款股份有限公司",
            capital : "99254413.44"
          },
          {
            name: "江西盈科行网络信息股份有限公司",
            capital : "9980531.45"
          },
          {
            name: "昆山金鑫新能源科技股份有限公司",
            capital : "9966207.53"
          },
          {
            name: "江苏远大信息股份有限公司",
            capital : "9964254.02"
          },

        ],
        table_3_CA: [
          {
            name: "宁波中药制药股份有限公司",
            capital : "1965-09-01"
          },
          {
            name: "浙江大洋生物科技集团股份有限公司",
            capital : "1976-01-01"
          },
          {
            name: "常州电站辅机股份有限公司",
            capital : "1979-01-15"
          },
          {
            name: "外贸无锡印刷股份有限公司",
            capital : "1980-04-15"
          },
          {
            name: "无锡煤矿机械股份有限公司",
            capital : "1980-06-05"
          },
        ],
      };
    },
    mounted() {
      this.chinaConfigure();
      this.drawpie();
    },
    beforeDestroy() {
      if (!this.chart) {
        return;
      }
      this.chart.dispose();
      this.chart = null;
    },
    methods: {
      drawpie() {
            //console.log(this.pieData);
            // 基于准备好的dom，初始化echarts实例
            this.myChart = this.$echarts.init(document.getElementById('myChart'));
            // 绘制图表
            this.myChart.setOption({
                //backgroundColor: '#2c343c',

                title: {
                    text: "行业分布图",
                    left: 'center',
                    top: 20,
                    textStyle: {
                        color: '#ccc'
                    }
                },

                tooltip: {
                    trigger: 'item',
                    formatter: '{a} <br/>{b} : {c} ({d}%)'
                },

                visualMap: {
                    show: false,
                    min: 80,
                    max: 600,
                    inRange: {
                        colorLightness: [0, 1]
                    }
                },
                series: [
                    {
                        name: '行业分布',
                        type: 'pie',
                        radius: '50%',
                        center: ['50%', '50%'],
                        data: [
                          {
                          "name": "建筑业",
                          "value": 357
                          },
                          {
                          "name": "能源行业",
                          "value": 139
                          },
                          {
                          "name": "金融业",
                          "value": 550
                          },
                          {
                          "name": "第一产业",
                          "value": 226
                          },
                          {
                          "name": "重工业",
                          "value": 2051
                          },
                          {
                          "name": "IT行业",
                          "value": 2120
                          },
                          {
                          "name": "轻工业",
                          "value": 1217
                          },
                          {
                          "name": "采掘业",
                          "value": 71
                          },
                          {
                          "name": "公共服务业",
                          "value": 50
                          },
                          {
                          "name": "科学研究业",
                          "value": 125
                          },
                          {
                          "name": "服务业",
                          "value": 669
                          },
                          {
                          "name": "交通运输业",
                          "value": 195
                          },
                        ],
                        roseType: 'radius',
                        label: {
                            color: 'rgba(255, 255, 255, 0.9)'
                        },
                        labelLine: {
                            lineStyle: {
                                color: 'rgba(255, 255, 255, 0.3)'
                            },
                            smooth: 0.2,
                            length: 10,
                            length2: 20
                        },
                        itemStyle: {
                            color: '#c23531',
                            shadowBlur: 200,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        },

                        animationType: 'scale',
                        animationEasing: 'elasticOut',
                        animationDelay: function (idx) {
                            return Math.random() * 200;
                        }
                    }
                ]
            });
      },
      chinaConfigure() {
        //console.log(this.userJson)
        let myChart = echarts.init(this.$refs.myEchart); //这里是为了获得容器所在位置    
        window.onresize = myChart.resize;
        myChart.setOption({ // 进行相关配置
          //backgroundColor: "#2c343c",
          title: {
                    text: "中国各省挂牌公司数",
                    left: 'center',
                    top: 10,
                    textStyle: {
                        color: '#ccc'
                    }
                },
          tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} '
          }, // 鼠标移到图里面的浮动提示框
          dataRange: {
            show: false,
            min: 0,
            max: 1000,
            text: ['High', 'Low'],
            realtime: true,
            calculable: true,
            color: ['orangered', 'yellow', 'lightskyblue']
          },
          geo: { // 这个是重点配置区
            map: 'china', // 表示中国地图
            roam: true,
            label: {
              normal: {
                show: true, // 是否显示对应地名
                textStyle: {
                  color: 'rgba(0,0,0,1)'
                }
              }
            },
            itemStyle: {
              normal: {
                borderColor: 'rgba(0, 0, 0, 0.2)'
              },
              emphasis: {
                areaColor: null,
                shadowOffsetX: 0,
                shadowOffsetY: 0,
                shadowBlur: 20,
                borderWidth: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          },
          series: [{
              type: 'scatter',
              coordinateSystem: 'geo' // 对应上方配置
            },
            {
              name: '挂牌企业数', // 浮动框的标题
              type: 'map',
              zoom: 2.2,
              geoIndex: 0,
              data: [
                      {
                      "name": "新疆",
                      "value": 65
                      },
                      {
                      "name":"西藏",
                      "value":7
                      },
                      {
                      "name":"青海",
                      "value":4
                      },
                      {
                      "name":"甘肃",
                      "value":32
                      },
                      {
                      "name":"四川",
                      "value":253
                      },
                      {
                      "name":"内蒙古",
                      "value":53
                      },
                      {
                      "name":"宁夏",
                      "value":49
                      },
                      {
                      "name":"陕西",
                      "value":135
                      },
                      {
                      "name":"重庆",
                      "value":104
                      },
                      {
                      "name":"贵州",
                      "value":50
                      },
                      {
                      "name":"云南",
                      "value":80
                      },
                      {
                      "name":"广西",
                      "value":64
                      },
                      {
                      "name":"湖南",
                      "value":172
                      },
                      {
                      "name":"湖北",
                      "value":302
                      },
                      {
                      "name":"广东",
                      "value":1249
                      },
                      {
                      "name":"海南",
                      "value":30
                      },
                      {
                      "name":"福建",
                      "value":301
                      },
                      {
                      "name":"江西",
                      "value":122
                      },
                      {
                      "name":"浙江",
                      "value":741
                      },
                      {
                      "name":"上海",
                      "value":684
                      },
                      {
                      "name":"江苏",
                      "value":1018
                      },
                      {
                      "name":"安徽",
                      "value":299
                      },
                      {
                      "name":"河南",
                      "value":299
                      },
                      {
                      "name":"山西",
                      "value":84
                      },
                      {
                      "name":"河北",
                      "value":205
                      },
                      {
                      "name":"北京",
                      "value":1133
                      },
                      {
                      "name":"天津",
                      "value":154
                      },
                      {
                      "name":"山东",
                      "value":517
                      },
                      {
                      "name":"辽宁",
                      "value":175
                      },
                      {
                      "name":"吉林",
                      "value":66
                      },
                      {
                      "name":"黑龙江",
                      "value":71
                      },
                      {
                      "name":"台湾",
                      "value":0
                      },
                      {
                      "name":"南海诸岛",
                      "value":0
                      },
                      {
                        "name": "香港",
                        "value": 0
                      },
                      {
                        "name": "澳门",
                        "value": 0
                      }
                    ]                        
            }
          ]
        })
      }
    }
  
}
</script>

<style>
.allview {
  /* background-color: #2c343c; */
  background-image: url("../../assets/img/bg3.png");
  background-size: cover;
  height:1500px;
  font-family:"微软雅黑";
  overflow-y:scroll;
}
.Otitle {
  color:azure;
  margin-top: 0px;
  
}
.OTitle {
  color:azure;
  margin-top: 20px;
  margin-bottom: 30px;
}
.Otable {
  margin-top: 10px;
  font-size: 14px;
  border-radius: 6px;
}
.Otable_2 {
  margin-top: 10px;
  font-size: 14px;
  border-radius: 6px;
}
.pieChart {
  margin-top: 20px;
}
.Otable_d {
  border:2px solid #ccc;
  border-radius: 6px;
  padding:5px;
}
.Otable_b {
  margin-top: 40px;
}
.left_up {
  border: 3px dashed rgb(255, 255, 255);
  margin-top:100px;
  margin-left: 20px;
  padding: 10px;
}
.pieChart {
  border: 2px solid rgb(255, 255, 255);
  margin-top:90px;
  margin-bottom: 10px;
  margin-right: -20px;
  padding: 10px;
  border-radius: 10px;
}
.mapChart {
  border: 2px solid rgb(255, 255, 255);
  margin-top:10px;
  margin-bottom: 10px;
  margin-left: 20px;
  margin-right: 20px;
  padding: 10px;
  border-radius: 10px;
}
.Otable_p {
  margin-left: 20px;
  margin-right: 20px;
}
</style>



