<template>
    <div class="login-wrap">
        <!-- <img src="./assets/logo.png"> -->
        <vue-particles
        color="#7FFFD4"
        :particleOpacity="0.7"
        :particlesNumber="50"
        shapeType="cirlce"
        :particleSize="3"
        linesColor="#48D1CC"
        :linesWidth="1"
        :lineLinked="true"
        :lineOpacity="0.5"
        :linesDistance="300"
        :moveSpeed="5"
        :hoverEffect="true"
        hoverMode="grab"
        :clickEffect="true"
        clickMode="push"
        class="lizi" 
      >
      </vue-particles> 
        <div class="ms-login">
            <div class="ms-title" style="color:white;">企业大数据征信系统</div>
            <el-form :model="param" :rules="rules" ref="register" label-width="0px" class="ms-content">
                <el-form-item prop="username">
                    <el-input v-model="param.username" placeholder="username">
                        <el-button slot="prepend" icon="el-icon-s-custom"></el-button>
                    </el-input>
                </el-form-item>
                <el-form-item prop="phonenumber">
                    <el-input v-model="param.phonenumber" placeholder="phonenumber">
                        <el-button slot="prepend" icon="el-icon-phone"></el-button>
                    </el-input>
                </el-form-item>
                <el-form-item prop="password">
                    <el-input
                        type="password"
                        placeholder="password"
                        v-model="param.password"
                        @keyup.enter.native="completeRegis_test()"
                        show-password
                    >
                        <el-button slot="prepend" icon="el-icon-lock"></el-button>
                    </el-input>
                </el-form-item>
                <!-- <div class="login-btn">
                    <el-button type="primary" @click="submitForm()">登录</el-button>
                </div> -->
                <div class="register-btn">
                    <el-button type="primary" @click="completeRegis_test()">注册完成，点击返回</el-button>
                </div>
                <!-- <p class="login-tips">Tips : 用户名和密码随便填。</p> -->
            </el-form>
        </div>
    </div>
</template>

<script>
import axios from "axios";
export default {
    data: function() {
        return {
            param: {
                username: '',
                phonenumber: '',
                password: '',
            },
            rules: {
                username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
                phonenumber: [{ required: true, message: '请输入用户手机号', trigger: 'blur' }],
                password: [{ required: true, message: '请输入密码', trigger: 'blur' }],
            },
        };
    },
    methods: {
        completeRegis() {
            this.$refs.register.validate(valid => {
                if (valid) {
                    this.$message.success('注册成功');
                    localStorage.setItem('ms_username', this.param.username);
                    this.$router.push('/login');
                } else {
                    this.$message.error('注册不成功');
                    console.log('error register!!');
                    return false;
                }
            });
        },
        completeRegis_test() {
            this.$refs.register.validate(valid => {
                if (valid) {
                    var qs_register = require('qs');
                    console.log({
                        "phone":this.param.phonenumber,
                        "name":this.param.username,
                        "pwd":this.param.password,
                    })
                    axios.post("http://121.89.181.241:8081/userInfo/userRegis",qs_register.stringify({
                        "phone":this.param.phonenumber,
                        "name":this.param.username,
                        "pwd":this.param.password,
                    },{indices:false}))
                    .then(responce=>{
                        if(responce.data.errcode==="0"){
                        this.$message.success('注册成功，返回登录界面');
                        //localStorage.setItem('ms_username', this.param.username);
                        this.$router.push('/login');
                        }
                        if(responce.data.errcode==="20001")
                        {
                            console.log(responce.data);
                            this.$message.success('connect but error');
                        }
                    })
                    .catch(function(error){
                        alert(error);
                    });

                    // this.$message.success('注册成功');
                    // localStorage.setItem('ms_username', this.param.username);
                    // this.$router.push('/login');
                } else {
                    this.$message.error('注册不成功');
                    console.log('error register!!');
                    return false;
                }
            });
        }
    },
};
</script>

<style scoped>
.login-wrap {
    position: relative;
    width: 100%;
    height: 100%;
    background-image: url(../../assets/img/login-bg.png);
    background-size: 100%;
}
.ms-title {
    width: 100%;
    line-height: 90px;
    text-align: center;
    font-size: 35px;
    font-family: "Helvetica Neue";
    
    color:#D2691E;
    border-bottom: 3px solid #C0FF3E;
    
}
.ms-login {
    position: absolute;
    left: 44%;
    top: 50%;
    width: 600px;
    margin: -190px 0 0 -175px;
    border-radius: 30px;
    background: rgba(163, 161, 161, 0.3);
    overflow: hidden;
    border: 3px solid #C0FF3E;
}
.ms-content {
     padding: 70px 70px;     
}
.login-btn {
    text-align: center;
}
.login-btn button {
    width: 100%;
    height: 36px;
    margin-bottom: 10px;
}

.register-btn{
    text-align: center;
}

.register-btn button{
    width: 100%;
    height: 36px;
    margin-bottom: 10px;
}

/* .login-tips {
    font-size: 12px;
    line-height: 30px;
    color:darkgreen;
} */
</style>