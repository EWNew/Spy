const SERVICE_PATH = "http://www.ewnb.top:80/biz/";
module.exports = SERVICE_PATH;   